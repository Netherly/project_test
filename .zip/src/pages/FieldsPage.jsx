// src/pages/FieldsPage.jsx
import React, { useState, useRef, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import "../styles/Fields.css";
import { fetchFields, saveFields } from "../api/fields";
import { fileUrl } from "../api/http";
import ConfirmationModal from "../components/modals/confirm/ConfirmationModal";

// лимит для изображений (500 КБ)
const MAX_IMAGE_BYTES = 500 * 1024;

const tabsConfig = [
  { key: "orderFields", label: "Поля заказа" },
  { key: "executorFields", label: "Поля исполнителя" },
  { key: "clientFields", label: "Поля клиента" },
  { key: "employeeFields", label: "Поля сотрудника" },
  { key: "assetsFields", label: "Поля активов" },
  { key: "financeFields", label: "Поля финансов" },
];

const initialValues = {
  orderFields: {
    intervals: [{ intervalValue: "" }],
    categories: [{ categoryInterval: "", categoryValue: "" }],
    currency: [],
  },
  executorFields: { currency: [], role: [] },
  clientFields: { source: [], category: [], country: [], currency: [], tag: [] },
  employeeFields: { country: [] },
  assetsFields: { currency: [], type: [], paymentSystem: [], cardDesigns: [] },
  financeFields: {
    articles: [{ articleValue: "" }],
    subarticles: [{ subarticleInterval: "", subarticleValue: "" }],
    subcategory: [],
  },
};

/* =========================
   Helpers
   ========================= */

// безопасно строим URL к файлу/картинке
function safeFileUrl(u) {
  if (!u) return "";
  const s = String(u).trim();
  if (s.startsWith("data:")) return s;
  if (/^https?:\/\//i.test(s)) return s;
  try {
    return fileUrl(s);
  } catch {
    return s;
  }
}

/**
 * Нормализуем ответ бэка (который теперь может отдавать объекты с id)
 * в тот вид, который ожидает текущий UI:
 *  - currency / role / source / ... → МАССИВЫ СТРОК
 *  - intervals → [{ intervalValue }]
 *  - categories → [{ categoryInterval, categoryValue }]
 *  - articles → [{ articleValue }]
 *  - subarticles → [{ subarticleInterval, subarticleValue }]
 *  - cardDesigns → [{ id, name, url, size? }]
 */
function normalizeFromBackend(input) {
  const data = input?.ok && input?.data ? input.data : input;
  const A = (v, def = []) => (Array.isArray(v) ? v : def);
  const S = (v) => (typeof v === "string" ? v : "");

  const pickName = (o) => (o?.name ? String(o.name) : "");
  const pickCodeOrName = (o) => (o?.code ? String(o.code) : o?.name ? String(o.name) : "");

  // ----- ORDER -----
  const rawIntervals = A(data?.orderFields?.intervals);
  const intervals = rawIntervals.map((x) => ({ intervalValue: S(x?.value ?? x?.intervalValue) })).filter((x) => x.intervalValue);

  const rawOrderCats = A(data?.orderFields?.categories);
  const categories = rawOrderCats
    .map((x) => ({
      categoryInterval: S(x?.intervalValue ?? x?.categoryInterval),
      categoryValue: S(x?.value ?? x?.categoryValue),
    }))
    .filter((x) => x.categoryInterval && x.categoryValue);

  const orderCurrency = A(data?.orderFields?.currency).map(pickCodeOrName);

  // ----- EXECUTOR -----
  const executorCurrency = A(data?.executorFields?.currency).map(pickCodeOrName);
  const roles = A(data?.executorFields?.role).map(pickName);

  // ----- CLIENT -----
  const clientSource = A(data?.clientFields?.source).map(pickName);
  const clientCategory = A(data?.clientFields?.category).map(pickName);
  const clientCountry = A(data?.clientFields?.country).map(pickName);
  const clientCurrency = A(data?.clientFields?.currency).map(pickCodeOrName);
  const clientTag = A(data?.clientFields?.tag).map(pickName);

  // ----- EMPLOYEE -----
  const employeeCountry = A(data?.employeeFields?.country).map(pickName);

  // ----- ASSETS -----
  const assetsCurrency = A(data?.assetsFields?.currency).map(pickCodeOrName);
  const assetsType = A(data?.assetsFields?.type).map(pickName);
  const assetsPaymentSystem = A(data?.assetsFields?.paymentSystem).map(pickName);
  const cardDesigns = A(data?.assetsFields?.cardDesigns).map((d) => ({
    id: d?.id || `${Date.now()}_${Math.random()}`,
    name: S(d?.name),
    url: S(d?.url),
    size: d?.size ?? null,
  }));

  // ----- FINANCE -----
  const articles = A(data?.financeFields?.articles)
    .map((a) => ({ articleValue: S(a?.articleValue ?? a?.name) }))
    .filter((a) => a.articleValue);

  const subarticles = A(data?.financeFields?.subarticles)
    .map((s) => ({
      subarticleInterval: S(s?.subarticleInterval ?? s?.articleName ?? s?.subcategoryName ?? s?.parent),
      subarticleValue: S(s?.subarticleValue ?? s?.name),
    }))
    .filter((s) => s.subarticleInterval && s.subarticleValue);

  const subcategory = A(data?.financeFields?.subcategory).map(pickName);

  return {
    orderFields: {
      intervals: intervals.length ? intervals : initialValues.orderFields.intervals,
      categories: categories.length ? categories : initialValues.orderFields.categories,
      currency: orderCurrency,
    },
    executorFields: {
      currency: executorCurrency,
      role: roles,
    },
    clientFields: {
      source: clientSource,
      category: clientCategory,
      country: clientCountry,
      currency: clientCurrency,
      tag: clientTag,
    },
    employeeFields: {
      country: employeeCountry,
    },
    assetsFields: {
      currency: assetsCurrency,
      type: assetsType,
      paymentSystem: assetsPaymentSystem,
      cardDesigns,
    },
    financeFields: {
      articles: articles.length ? articles : initialValues.financeFields.articles,
      subarticles: subarticles.length ? subarticles : initialValues.financeFields.subarticles,
      subcategory,
    },
  };
}

// мягкая очистка перед отправкой на бэк (как и раньше)
function serializeForSave(values) {
  const trim = (s) => (typeof s === "string" ? s.trim() : s);
  const filterStrings = (arr = []) => (Array.isArray(arr) ? arr : []).map((v) => trim(v ?? "")).filter((v) => v !== "");

  const mapIntervals = (arr = []) =>
    (Array.isArray(arr) ? arr : [])
      .map((it) => ({ intervalValue: trim(it?.intervalValue ?? "") }))
      .filter((it) => it.intervalValue !== "");

  const mapCategories = (arr = []) =>
    (Array.isArray(arr) ? arr : [])
      .map((it) => ({
        categoryInterval: trim(it?.categoryInterval ?? ""),
        categoryValue: trim(it?.categoryValue ?? ""),
      }))
      .filter((it) => it.categoryInterval !== "" && it.categoryValue !== "");

  const mapArticles = (arr = []) =>
    (Array.isArray(arr) ? arr : [])
      .map((it) => ({ articleValue: trim(it?.articleValue ?? "") }))
      .filter((it) => it.articleValue !== "");

  const mapSubarticles = (arr = []) =>
    (Array.isArray(arr) ? arr : [])
      .map((it) => ({
        subarticleInterval: trim(it?.subarticleInterval ?? ""),
        subarticleValue: trim(it?.subarticleValue ?? ""),
      }))
      .filter((it) => it.subarticleInterval !== "" && it.subarticleValue !== "");

  const mapDesigns = (arr = []) =>
    (Array.isArray(arr) ? arr : [])
      .map((d) => ({
        id: d?.id || `${Date.now()}_${Math.random()}`,
        name: trim(d?.name ?? ""),
        url: trim(d?.url ?? ""),
        size: d?.size ?? null,
      }))
      .filter((d) => d.name !== "" && d.url !== "");

  return {
    orderFields: {
      intervals: mapIntervals(values?.orderFields?.intervals),
      categories: mapCategories(values?.orderFields?.categories),
      currency: filterStrings(values?.orderFields?.currency),
    },
    executorFields: {
      currency: filterStrings(values?.executorFields?.currency),
      role: filterStrings(values?.executorFields?.role),
    },
    clientFields: {
      source: filterStrings(values?.clientFields?.source),
      category: filterStrings(values?.clientFields?.category),
      country: filterStrings(values?.clientFields?.country),
      currency: filterStrings(values?.clientFields?.currency),
      tag: filterStrings(values?.clientFields?.tag),
    },
    employeeFields: {
      country: filterStrings(values?.employeeFields?.country),
    },
    assetsFields: {
      currency: filterStrings(values?.assetsFields?.currency),
      type: filterStrings(values?.assetsFields?.type),
      paymentSystem: filterStrings(values?.assetsFields?.paymentSystem),
      cardDesigns: mapDesigns(values?.assetsFields?.cardDesigns),
    },
    financeFields: {
      articles: mapArticles(values?.financeFields?.articles),
      subarticles: mapSubarticles(values?.financeFields?.subarticles),
      subcategory: filterStrings(values?.financeFields?.subcategory),
    },
  };
}

/* =========================
   Подкомпоненты
   ========================= */

const IntervalFields = ({ intervals, onIntervalChange, onAddInterval, onRemoveInterval }) => (
  <div className="field-row">
    <label className="field-label">Интервал</label>
    <div className="category-fields-container">
      {(intervals || []).map((interval, index) => (
        <div key={index} className="category-field-group">
          <div className="category-container">
            <div className="category-full">
              <input
                type="text"
                value={interval.intervalValue || ""}
                onChange={(e) => {
                  e.stopPropagation();
                  onIntervalChange(index, "intervalValue", e.target.value);
                }}
                placeholder="Введите интервал"
                className="text-input"
              />
            </div>
            {intervals.length > 1 && (
              <button className="remove-category-btn" onClick={() => onRemoveInterval(index)} title="Удалить интервал">
                ×
              </button>
            )}
          </div>
        </div>
      ))}
      <button className="add-category-btn" onClick={onAddInterval}>
        + Добавить интервал
      </button>
    </div>
  </div>
);

const CategoryFields = ({
  categories,
  onCategoryChange,
  onAddCategory,
  onRemoveCategory,
  openDropdowns,
  onToggleDropdown,
  availableIntervals,
}) => (
  <div className="field-row category-field">
    <label className="field-label">Категория</label>
    <div className="category-fields-container">
      {(categories || []).map((category, index) => (
        <div key={index} className="category-field-group">
          <div className="category-container">
            <div className="category-left">
              <div className="dropdown-container">
                <div
                  className={`dropdown-trigger-category ${category.categoryInterval ? "has-value" : ""}`}
                  onClick={(e) => onToggleDropdown(index, e)}
                >
                  <span className="dropdown-value">{category.categoryInterval || "Выберите интервал"}</span>
                  <span className={`dropdown-arrow ${openDropdowns[`category-${index}-interval`] ? "open" : ""}`}>▼</span>
                </div>
                <div className={`dropdown-menu ${openDropdowns[`category-${index}-interval`] ? "open" : ""}`}>
                  {(availableIntervals || []).length > 0 ? (
                    availableIntervals.map((option, optionIndex) => (
                      <div
                        key={optionIndex}
                        className={`dropdown-option ${category.categoryInterval === option ? "selected" : ""}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onCategoryChange(index, "categoryInterval", option);
                        }}
                      >
                        {option}
                      </div>
                    ))
                  ) : (
                    <div className="dropdown-option disabled-option">Сначала добавьте интервалы</div>
                  )}
                </div>
              </div>
            </div>
            <div className="category-right">
              <input
                type="text"
                value={category.categoryValue || ""}
                onChange={(e) => {
                  e.stopPropagation();
                  onCategoryChange(index, "categoryValue", e.target.value);
                }}
                placeholder="Введите значение"
                className="text-input"
              />
            </div>
            {categories.length > 1 && (
              <button className="remove-category-btn" onClick={() => onRemoveCategory(index)} title="Удалить категорию">
                ×
              </button>
            )}
          </div>
        </div>
      ))}
      <button className="add-category-btn" onClick={onAddCategory}>
        + Добавить категорию
      </button>
    </div>
  </div>
);

const ArticleFields = ({ articles, onArticleChange, onAddArticle, onRemoveArticle }) => (
  <div className="field-row">
    <label className="field-label">Статья</label>
    <div className="category-fields-container">
      {(articles || []).map((article, index) => (
        <div key={index} className="category-field-group">
          <div className="category-container">
            <div className="category-full">
              <input
                type="text"
                value={article.articleValue || ""}
                onChange={(e) => {
                  e.stopPropagation();
                  onArticleChange(index, "articleValue", e.target.value);
                }}
                placeholder="Введите статью"
                className="text-input"
              />
            </div>
            {articles.length > 1 && (
              <button className="remove-category-btn" onClick={() => onRemoveArticle(index)} title="Удалить статью">
                ×
              </button>
            )}
          </div>
        </div>
      ))}
      <button className="add-category-btn" onClick={onAddArticle}>
        + Добавить статью
      </button>
    </div>
  </div>
);

const SubarticleFields = ({
  subarticles,
  onSubarticleChange,
  onAddSubarticle,
  onRemoveSubarticle,
  openDropdowns,
  onToggleDropdown,
  availableArticles,
  availableSubcategories,
}) => (
  <div className="field-row article-field">
    <label className="field-label">Подстатья</label>
    <div className="category-fields-container">
      {(subarticles || []).map((subarticle, index) => (
        <div key={index} className="category-field-group">
          <div className="category-container">
            <div className="category-left">
              <div className="dropdown-container">
                <div
                  className={`dropdown-trigger-article ${subarticle.subarticleInterval ? "has-value" : ""}`}
                  onClick={(e) => onToggleDropdown(index, e)}
                >
                  <span className="dropdown-value">{subarticle.subarticleInterval || "Выберите статью/подкатегорию"}</span>
                  <span className={`dropdown-arrow ${openDropdowns[`subarticle-${index}-interval`] ? "open" : ""}`}>▼</span>
                </div>
                <div className={`dropdown-menu ${openDropdowns[`subarticle-${index}-interval`] ? "open" : ""}`}>
                  {(availableArticles || []).length > 0 ? (
                    availableArticles.map((option, optionIndex) => (
                      <div
                        key={`art-${optionIndex}`}
                        className={`dropdown-option ${subarticle.subarticleInterval === option ? "selected" : ""}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSubarticleChange(index, "subarticleInterval", option);
                        }}
                      >
                        {option}
                      </div>
                    ))
                  ) : (
                    <div className="dropdown-option disabled-option">Сначала добавьте статьи</div>
                  )}
                  {(availableSubcategories || []).map((option, optionIndex) => (
                    <div
                      key={`subcat-${optionIndex}`}
                      className={`dropdown-option ${subarticle.subarticleInterval === option ? "selected" : ""}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSubarticleChange(index, "subarticleInterval", option);
                      }}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="category-right">
              <input
                type="text"
                value={subarticle.subarticleValue || ""}
                onChange={(e) => {
                  e.stopPropagation();
                  onSubarticleChange(index, "subarticleValue", e.target.value);
                }}
                placeholder="Введите значение"
                className="text-input"
              />
            </div>
            {subarticles.length > 1 && (
              <button className="remove-category-btn" onClick={() => onRemoveSubarticle(index)} title="Удалить подстатью">
                ×
              </button>
            )}
          </div>
        </div>
      ))}
      <button className="add-category-btn" onClick={onAddSubarticle}>
        + Добавить подстатью
      </button>
    </div>
  </div>
);

// универсальный список строк
const EditableList = ({ items = [], onAdd, onRemove, placeholder }) => (
  <div className="category-fields-container">
    {(items || []).map((item, index) => (
      <div key={`${item}-${index}`} className="category-field-group">
        <div className="category-container">
          <div className="category-full">
            <input
              type="text"
              value={item}
              onChange={(e) => {
                const newValue = e.target.value;
                const newItems = [...(items || [])];
                newItems[index] = newValue;
                onAdd(newItems);
              }}
              placeholder={placeholder}
              className="text-input"
            />
          </div>
          <button className="remove-category-btn" onClick={() => onRemove(index)} title="Удалить">
            ×
          </button>
        </div>
      </div>
    ))}
    <button className="add-category-btn" onClick={() => onAdd([...(items || []), ""])}>
      + Добавить
    </button>
  </div>
);

/* ============ ДИЗАЙНЫ КАРТ =========== */
const CardDesignUpload = ({ cardDesigns = [], onAdd, onRemove, onError }) => {
  const fileInputRefs = useRef([]);

  const ensureDesign = (arr, index) => {
    const copy = [...arr];
    copy[index] = {
      id: copy[index]?.id || `${Date.now()}_${Math.random()}`,
      name: copy[index]?.name || "",
      url: copy[index]?.url || "",
      size: copy[index]?.size ?? null,
    };
    return copy;
  };

  const triggerFile = (i) => fileInputRefs.current[i]?.click();

  const handleFileUpload = (event, index) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;
    const file = files[0];

    if (!file.type.startsWith("image/")) {
      onError?.({ title: "Неверный формат файла", message: "Выберите изображение (PNG/JPEG/SVG и т.п.)." });
      event.target.value = "";
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      onError?.({
        title: "Слишком большой файл",
        message: `Размер изображения превышает ${(MAX_IMAGE_BYTES / 1024).toFixed(0)} КБ.`,
      });
      event.target.value = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const next = ensureDesign(cardDesigns, index);
      next[index] = { ...next[index], url: e.target.result, size: file.size };
      onAdd(next);
    };
    reader.onerror = () => {
      onError?.({ title: "Ошибка чтения файла", message: "Не удалось прочитать выбранное изображение." });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const handleNameChange = (index, newName) => {
    const next = ensureDesign(cardDesigns, index);
    next[index] = { ...next[index], name: newName };
    onAdd(next);
  };

  const addEmpty = () => {
    onAdd([...(cardDesigns || []), { id: `${Date.now()}_${Math.random()}`, name: "", url: "", size: null }]);
  };

  return (
    <div className="category-fields-container">
      {(cardDesigns || []).map((design, index) => (
        <div key={design.id || index} className="category-field-group">
          <div className="card-design-row">
            <div className="card-design-input">
              <input
                type="text"
                value={design.name || ""}
                onChange={(e) => {
                  e.stopPropagation();
                  handleNameChange(index, e.target.value);
                }}
                placeholder="Введите название дизайна"
                className="text-input"
              />
            </div>

            <div className="card-design-upload">
              <input
                ref={(el) => (fileInputRefs.current[index] = el)}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileUpload(e, index)}
                style={{ display: "none" }}
              />

              {design.url ? (
                <div className="card-design-item">
                  <div
                    className="card-design-preview"
                    title="Кликните, чтобы заменить"
                    onClick={() => triggerFile(index)}
                  >
                    <img
                      src={safeFileUrl(design.url)}
                      alt={design.name || "card design"}
                      className="card-design-image"
                    />
                  </div>

                  <button
                    type="button"
                    className="card-design-remove"
                    title="Удалить дизайн"
                    aria-label="Удалить дизайн"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemove(index);
                    }}
                  >
                    ×
                  </button>

                  <div className="card-design-actions">
                    <button
                      type="button"
                      className="upload-design-btn"
                      onClick={() => triggerFile(index)}
                      title="Заменить изображение"
                    >
                      Заменить
                    </button>
                  </div>
                </div>
              ) : (
                <div className="card-design-item">
                  <button type="button" className="upload-design-btn" onClick={() => triggerFile(index)}>
                    + Загрузить изображение
                  </button>

                  <button
                    type="button"
                    className="card-design-remove"
                    title="Удалить дизайн"
                    aria-label="Удалить дизайн"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemove(index);
                    }}
                  >
                    ×
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}

      <button type="button" className="add-category-btn" onClick={addEmpty}>
        + Добавить дизайн карты
      </button>
    </div>
  );
};

/* =========================
   Основной компонент
   ========================= */
function FieldsPage() {
  const [selectedValues, setSelectedValues] = useState(initialValues);
  const [savedValues, setSavedValues] = useState(initialValues);
  const [hasChanges, setHasChanges] = useState(false);
  const [activeTab, setActiveTab] = useState("orderFields");
  const [openDropdowns, setOpenDropdowns] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // состояние модалки
  const [modal, setModal] = useState({
    open: false,
    title: "",
    message: "",
    confirmText: "OK",
    cancelText: "Закрыть",
    onConfirm: null,
    onCancel: null,
  });

  const containerRef = useRef(null);

  // загрузка
  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      try {
        const raw = await fetchFields();
        const normalized = normalizeFromBackend(raw);
        console.log("Получены актуальные fields с бэка:", raw);
        if (!mounted) return;
        setSelectedValues(normalized);
        setSavedValues(normalized);
        setHasChanges(false);
      } catch (e) {
        setModal({
          open: true,
          title: "Ошибка загрузки списков",
          message: e?.message || "Не удалось получить данные с сервера.",
          confirmText: "OK",
          cancelText: "Закрыть",
          onConfirm: () => setModal((m) => ({ ...m, open: false })),
          onCancel: () => setModal((m) => ({ ...m, open: false })),
        });
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const checkForChanges = (next) => {
    const changed = JSON.stringify(next) !== JSON.stringify(savedValues);
    if (hasChanges !== changed) setHasChanges(changed);
  };
  const applyAndCheck = (next) => {
    setSelectedValues(next);
    checkForChanges(next);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = serializeForSave(selectedValues);
      await saveFields(payload);
      const fresh = await fetchFields();
      const normalized = normalizeFromBackend(fresh);
      setSelectedValues(normalized);
      setSavedValues(normalized);
      setHasChanges(false);
      setOpenDropdowns({});
      setModal({
        open: true,
        title: "Успешно",
        message: "Изменения сохранены.",
        confirmText: "OK",
        cancelText: "Закрыть",
        onConfirm: () => setModal((m) => ({ ...m, open: false })),
        onCancel: () => setModal((m) => ({ ...m, open: false })),
      });
    } catch (e) {
      setModal({
        open: true,
        title: "Ошибка сохранения",
        message: e?.message || "Не удалось сохранить изменения.",
        confirmText: "OK",
        cancelText: "Закрыть",
        onConfirm: () => setModal((m) => ({ ...m, open: false })),
        onCancel: () => setModal((m) => ({ ...m, open: false })),
      });
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (!hasChanges) {
      setSelectedValues(savedValues);
      setOpenDropdowns({});
      return;
    }
    setModal({
      open: true,
      title: "Отменить изменения?",
      message: "Все несохранённые изменения будут потеряны.",
      confirmText: "Да",
      cancelText: "Отмена",
      onConfirm: () => {
        setModal((m) => ({ ...m, open: false }));
        setSelectedValues(savedValues);
        setHasChanges(false);
        setOpenDropdowns({});
      },
      onCancel: () => setModal((m) => ({ ...m, open: false })),
    });
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setOpenDropdowns({});
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (group, field, value) =>
    applyAndCheck({ ...selectedValues, [group]: { ...selectedValues[group], [field]: value } });

  // ====== Order ======
  const handleIntervalChange = (index, field, value) => {
    const curr = selectedValues.orderFields.intervals || [];
    const copy = [...curr];
    copy[index] = { ...copy[index], [field]: value };
    applyAndCheck({ ...selectedValues, orderFields: { ...selectedValues.orderFields, intervals: copy } });
  };

  const handleCategoryChange = (index, field, value) => {
    const curr = selectedValues.orderFields.categories || [];
    const copy = [...curr];
    copy[index] = { ...copy[index], [field]: value };
    applyAndCheck({ ...selectedValues, orderFields: { ...selectedValues.orderFields, categories: copy } });
    if (field === "categoryInterval") {
      setOpenDropdowns((prev) => ({ ...prev, [`category-${index}-interval`]: false }));
    }
  };

  const addInterval = () => {
    handleInputChange("orderFields", "intervals", [
      ...(selectedValues.orderFields.intervals || []),
      { intervalValue: "" },
    ]);
  };
  const addCategory = () => {
    handleInputChange("orderFields", "categories", [
      ...(selectedValues.orderFields.categories || []),
      { categoryInterval: "", categoryValue: "" },
    ]);
  };

  const removeInterval = (index) => {
    const curr = selectedValues.orderFields.intervals || [];
    if (curr.length <= 1) return;
    setModal({
      open: true,
      title: "Удалить интервал?",
      message: "Это действие нельзя отменить.",
      confirmText: "Да",
      cancelText: "Отмена",
      onConfirm: () => {
        setModal((m) => ({ ...m, open: false }));
        const copy = curr.filter((_, i) => i !== index);
        handleInputChange("orderFields", "intervals", copy);
      },
      onCancel: () => setModal((m) => ({ ...m, open: false })),
    });
  };

  const removeCategory = (index) => {
    const curr = selectedValues.orderFields.categories || [];
    if (curr.length <= 1) return;
    setModal({
      open: true,
      title: "Удалить категорию?",
      message: "Это действие нельзя отменить.",
      confirmText: "Да",
      cancelText: "Отмена",
      onConfirm: () => {
        setModal((m) => ({ ...m, open: false }));
        const copy = curr.filter((_, i) => i !== index);
        handleInputChange("orderFields", "categories", copy);
      },
      onCancel: () => setModal((m) => ({ ...m, open: false })),
    });
  };

  // ====== Finance ======
  const handleArticleChange = (index, field, value) => {
    const curr = selectedValues.financeFields.articles || [];
    const copy = [...curr];
    copy[index] = { ...copy[index], [field]: value };
    applyAndCheck({ ...selectedValues, financeFields: { ...selectedValues.financeFields, articles: copy } });
  };

  const handleSubarticleChange = (index, field, value) => {
    const curr = selectedValues.financeFields.subarticles || [];
    const copy = [...curr];
    copy[index] = { ...copy[index], [field]: value };
    applyAndCheck({ ...selectedValues, financeFields: { ...selectedValues.financeFields, subarticles: copy } });
    if (field === "subarticleInterval") {
      setOpenDropdowns((prev) => ({ ...prev, [`subarticle-${index}-interval`]: false }));
    }
  };

  const addArticle = () => {
    handleInputChange("financeFields", "articles", [
      ...(selectedValues.financeFields.articles || []),
      { articleValue: "" },
    ]);
  };
  const addSubarticle = () => {
    handleInputChange("financeFields", "subarticles", [
      ...(selectedValues.financeFields.subarticles || []),
      { subarticleInterval: "", subarticleValue: "" },
    ]);
  };

  const removeArticle = (index) => {
    const curr = selectedValues.financeFields.articles || [];
    if (curr.length <= 1) return;
    setModal({
      open: true,
      title: "Удалить статью?",
      message: "Это действие нельзя отменить.",
      confirmText: "Да",
      cancelText: "Отмена",
      onConfirm: () => {
        setModal((m) => ({ ...m, open: false }));
        const copy = curr.filter((_, i) => i !== index);
        handleInputChange("financeFields", "articles", copy);
      },
      onCancel: () => setModal((m) => ({ ...m, open: false })),
    });
  };

  const removeSubarticle = (index) => {
    const curr = selectedValues.financeFields.subarticles || [];
    if (curr.length <= 1) return;
    setModal({
      open: true,
      title: "Удалить подстатью?",
      message: "Это действие нельзя отменить.",
      confirmText: "Да",
      cancelText: "Отмена",
      onConfirm: () => {
        setModal((m) => ({ ...m, open: false }));
        const copy = curr.filter((_, i) => i !== index);
        handleInputChange("financeFields", "subarticles", copy);
      },
      onCancel: () => setModal((m) => ({ ...m, open: false })),
    });
  };

  // ====== Dropdown helpers ======
  const toggleCategoryDropdown = (index, event) => {
    event.stopPropagation();
    const key = `category-${index}-interval`;
    setOpenDropdowns((prev) => ({ [key]: !prev[key] }));
  };
  const toggleSubarticleDropdown = (index, event) => {
    event.stopPropagation();
    const key = `subarticle-${index}-interval`;
    setOpenDropdowns((prev) => ({ [key]: !prev[key] }));
  };

  const getAvailableIntervals = () => {
    const intervals = selectedValues.orderFields.intervals || [];
    return intervals.map((i) => i.intervalValue).filter((v) => v && v.trim() !== "");
    };
  const getAvailableArticles = () => {
    const articles = selectedValues.financeFields.articles || [];
    return articles.map((a) => a.articleValue).filter((v) => v && v.trim() !== "");
  };

  const renderActiveTabFields = () => {
    switch (activeTab) {
      case "orderFields":
        return (
          <div className="fields-vertical-grid">
            <IntervalFields
              intervals={selectedValues.orderFields.intervals || [{ intervalValue: "" }]}
              onIntervalChange={handleIntervalChange}
              onAddInterval={addInterval}
              onRemoveInterval={removeInterval}
            />
            <CategoryFields
              categories={selectedValues.orderFields.categories || [{ categoryInterval: "", categoryValue: "" }]}
              onCategoryChange={handleCategoryChange}
              onAddCategory={addCategory}
              onRemoveCategory={removeCategory}
              openDropdowns={openDropdowns}
              onToggleDropdown={toggleCategoryDropdown}
              availableIntervals={getAvailableIntervals()}
            />
            <div className="field-row">
              <label className="field-label">Валюта</label>
              <EditableList
                items={selectedValues.orderFields.currency || []}
                onAdd={(newItems) => handleInputChange("orderFields", "currency", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.orderFields.currency || []).filter((_, i) => i !== index);
                  handleInputChange("orderFields", "currency", newItems);
                }}
                placeholder="Введите значение валюты"
              />
            </div>
          </div>
        );
      case "executorFields":
        return (
          <div className="fields-vertical-grid">
            <div className="field-row">
              <label className="field-label">Валюта</label>
              <EditableList
                items={selectedValues.executorFields.currency || []}
                onAdd={(newItems) => handleInputChange("executorFields", "currency", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.executorFields.currency || []).filter((_, i) => i !== index);
                  handleInputChange("executorFields", "currency", newItems);
                }}
                placeholder="Введите значение валюты"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Роль</label>
              <EditableList
                items={selectedValues.executorFields.role || []}
                onAdd={(newItems) => handleInputChange("executorFields", "role", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.executorFields.role || []).filter((_, i) => i !== index);
                  handleInputChange("executorFields", "role", newItems);
                }}
                placeholder="Введите роль"
              />
            </div>
          </div>
        );
      case "clientFields":
        return (
          <div className="fields-vertical-grid">
            <div className="field-row">
              <label className="field-label">Категория</label>
              <EditableList
                items={selectedValues.clientFields.category || []}
                onAdd={(newItems) => handleInputChange("clientFields", "category", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.clientFields.category || []).filter((_, i) => i !== index);
                  handleInputChange("clientFields", "category", newItems);
                }}
                placeholder="Введите категорию"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Источник</label>
              <EditableList
                items={selectedValues.clientFields.source || []}
                onAdd={(newItems) => handleInputChange("clientFields", "source", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.clientFields.source || []).filter((_, i) => i !== index);
                  handleInputChange("clientFields", "source", newItems);
                }}
                placeholder="Введите источник"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Страна</label>
              <EditableList
                items={selectedValues.clientFields.country || []}
                onAdd={(newItems) => handleInputChange("clientFields", "country", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.clientFields.country || []).filter((_, i) => i !== index);
                  handleInputChange("clientFields", "country", newItems);
                }}
                placeholder="Введите страну"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Валюта</label>
              <EditableList
                items={selectedValues.clientFields.currency || []}
                onAdd={(newItems) => handleInputChange("clientFields", "currency", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.clientFields.currency || []).filter((_, i) => i !== index);
                  handleInputChange("clientFields", "currency", newItems);
                }}
                placeholder="Введите валюту"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Тег</label>
              <EditableList
                items={selectedValues.clientFields.tag || []}
                onAdd={(newItems) => handleInputChange("clientFields", "tag", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.clientFields.tag || []).filter((_, i) => i !== index);
                  handleInputChange("clientFields", "tag", newItems);
                }}
                placeholder="Введите тег"
              />
            </div>
          </div>
        );
      case "employeeFields":
        return (
          <div className="fields-vertical-grid">
            <div className="field-row">
              <label className="field-label">Страна</label>
              <EditableList
                items={selectedValues.employeeFields.country || []}
                onAdd={(newItems) => handleInputChange("employeeFields", "country", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.employeeFields.country || []).filter((_, i) => i !== index);
                  handleInputChange("employeeFields", "country", newItems);
                }}
                placeholder="Введите страну"
              />
            </div>
          </div>
        );
      case "assetsFields":
        return (
          <div className="fields-vertical-grid">
            <div className="field-row">
              <label className="field-label">Валюта счета</label>
              <EditableList
                items={selectedValues.assetsFields.currency || []}
                onAdd={(newItems) => handleInputChange("assetsFields", "currency", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.assetsFields.currency || []).filter((_, i) => i !== index);
                  handleInputChange("assetsFields", "currency", newItems);
                }}
                placeholder="Введите валюту счета"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Тип</label>
              <EditableList
                items={selectedValues.assetsFields.type || []}
                onAdd={(newItems) => handleInputChange("assetsFields", "type", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.assetsFields.type || []).filter((_, i) => i !== index);
                  handleInputChange("assetsFields", "type", newItems);
                }}
                placeholder="Введите тип"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Платежная система</label>
              <EditableList
                items={selectedValues.assetsFields.paymentSystem || []}
                onAdd={(newItems) => handleInputChange("assetsFields", "paymentSystem", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.assetsFields.paymentSystem || []).filter((_, i) => i !== index);
                  handleInputChange("assetsFields", "paymentSystem", newItems);
                }}
                placeholder="Введите платежную систему"
              />
            </div>
            <div className="field-row">
              <label className="field-label">Дизайн карты</label>
              <CardDesignUpload
                cardDesigns={selectedValues.assetsFields.cardDesigns || []}
                onAdd={(newItems) => handleInputChange("assetsFields", "cardDesigns", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.assetsFields.cardDesigns || []).filter((_, i) => i !== index);
                  handleInputChange("assetsFields", "cardDesigns", newItems);
                }}
                onError={({ title, message }) =>
                  setModal({
                    open: true,
                    title,
                    message,
                    confirmText: "OK",
                    cancelText: "Закрыть",
                    onConfirm: () => setModal((m) => ({ ...m, open: false })),
                    onCancel: () => setModal((m) => ({ ...m, open: false })),
                  })
                }
              />
            </div>
          </div>
        );
      case "financeFields":
        return (
          <div className="fields-vertical-grid">
            <ArticleFields
              articles={selectedValues.financeFields?.articles || [{ articleValue: "" }]}
              onArticleChange={handleArticleChange}
              onAddArticle={addArticle}
              onRemoveArticle={removeArticle}
            />
            <div className="field-row">
              <label className="field-label">Подкатегория</label>
              <EditableList
                items={selectedValues.financeFields.subcategory || []}
                onAdd={(newItems) => handleInputChange("financeFields", "subcategory", newItems)}
                onRemove={(index) => {
                  const newItems = (selectedValues.financeFields.subcategory || []).filter((_, i) => i !== index);
                  handleInputChange("financeFields", "subcategory", newItems);
                }}
                placeholder="Введите подкатегорию"
              />
            </div>
            <SubarticleFields
              subarticles={selectedValues.financeFields?.subarticles || [{ subarticleInterval: "", subarticleValue: "" }]}
              onSubarticleChange={handleSubarticleChange}
              onAddSubarticle={addSubarticle}
              onRemoveSubarticle={removeSubarticle}
              openDropdowns={openDropdowns}
              onToggleDropdown={toggleSubarticleDropdown}
              availableArticles={getAvailableArticles()}
              availableSubcategories={selectedValues.financeFields?.subcategory || []}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div ref={containerRef} className="fields-main-container">
      <Sidebar />
      <div className="fields-main-container-wrapper">
        <div className="header">
          <div className="header-content">
            <div className="header-left">
              <h1 className="lists-title">СПИСКИ</h1>
            </div>
            <div className="header-actions">
              {loading && <span className="loading-label">Загрузка…</span>}
              {saving && <span className="loading-label">Сохранение…</span>}
              {hasChanges && !saving && (
                <>
                  <button className="save-btn" onClick={handleSave}>Сохранить</button>
                  <button className="cancel-btn" onClick={handleCancel}>Отменить</button>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="fields-container">
          <div className="main-content-wrapper">
            <div className="tabs-content-wrapper">
              <div className="tabs-container">
                {tabsConfig.map((tab) => (
                  <button
                    key={tab.key}
                    className={`tab-button ${activeTab === tab.key ? "active" : ""}`}
                    onClick={() => {
                      setActiveTab(tab.key);
                      setOpenDropdowns({});
                    }}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <div className="fields-content">
                <div className="fields-box">{renderActiveTabFields()}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {modal.open && (
        <ConfirmationModal
          title={modal.title}
          message={modal.message}
          confirmText={modal.confirmText}
          cancelText={modal.cancelText}
          onConfirm={modal.onConfirm}
          onCancel={modal.onCancel}
        />
      )}
    </div>
  );
}

export default FieldsPage;
