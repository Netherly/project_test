// src/api/fields.js
import { httpGet, httpPut, fileUrl } from "./http";

/**
 * Единый эндпоинт:
 *   GET  /api/fields  -> весь объект полей
 *   PUT  /api/fields  -> сохранить весь объект полей (полная синхронизация)
 */

const unwrap = (resp) => {
  if (resp && typeof resp === "object" && "ok" in resp) {
    if (resp.ok) return resp.data;
    const err = new Error(resp?.error || "Request failed");
    err.payload = resp;
    throw err;
  }
  return resp;
};

export async function fetchFields() {
  const r = await httpGet("/fields");
  return unwrap(r);
}

export async function saveFields(payload) {
  const r = await httpPut("/fields", payload);
  return unwrap(r);
}

/**
 * Нормализация структуры на фронте:
 * - НЕ превращаем элементы в строки — сохраняем {id,...}
 * - Добавляем cardDesigns.viewUrl для удобного <img src=...>
 */
export function withDefaults(fields) {
  const safeArr = (x) => (Array.isArray(x) ? x : []);
  const safeObj = (x) => (x && typeof x === "object" ? x : {});
  const f = safeObj(fields);

  return {
    // ===== ORDER =====
    orderFields: {
      // [{ id, value }]
      intervals: safeArr(f?.orderFields?.intervals),
      // [{ id, value, intervalId, intervalValue }]
      categories: safeArr(f?.orderFields?.categories),
      // [{ id, code, name }]
      currency: safeArr(f?.orderFields?.currency),
    },

    // ===== EXECUTOR =====
    executorFields: {
      // [{ id, code, name }]
      currency: safeArr(f?.executorFields?.currency),
      // [{ id, name }]
      role: safeArr(f?.executorFields?.role),
    },

    // ===== CLIENT =====
    clientFields: {
      // [{ id, name }]
      source: safeArr(f?.clientFields?.source),
      // [{ id, name }]
      category: safeArr(f?.clientFields?.category),
      // [{ id, name }]
      country: safeArr(f?.clientFields?.country),
      // [{ id, code, name }]
      currency: safeArr(f?.clientFields?.currency),
      // [{ id, name, color }]
      tag: safeArr(f?.clientFields?.tag),
    },

    // ===== EMPLOYEE =====
    employeeFields: {
      // [{ id, name }]
      country: safeArr(f?.employeeFields?.country),
    },

    // ===== ASSETS =====
    assetsFields: {
      // [{ id, code, name }]
      currency: safeArr(f?.assetsFields?.currency),
      // [{ id, name }]
      type: safeArr(f?.assetsFields?.type),
      // [{ id, name }]
      paymentSystem: safeArr(f?.assetsFields?.paymentSystem),
      // [{ id, name, url }] + вычисляемый viewUrl
      cardDesigns: safeArr(f?.assetsFields?.cardDesigns).map((d) => ({
        ...d,
        viewUrl: fileUrl(d?.url || ""),
      })),
    },

    // ===== FINANCE =====
    financeFields: {
      // [{ id, name }]
      articles: safeArr(f?.financeFields?.articles),
      // [{ id, name, articleId, articleName, subcategoryId, subcategoryName }]
      subarticles: safeArr(f?.financeFields?.subarticles),
      // [{ id, name }]
      subcategory: safeArr(f?.financeFields?.subcategory),
    },
  };
}

/** Работа с одной группой (вкладкой) */
export async function getGroup(groupKey) {
  const all = withDefaults(await fetchFields());
  return all[groupKey] || {};
}

export async function setGroup(groupKey, groupData) {
  const all = withDefaults(await fetchFields());
  const next = { ...all, [groupKey]: groupData || {} };
  return saveFields(next);
}

/** Адресные методы (все через PUT /fields) */
export const FieldsAPI = {
  // ===== ORDER =====
  async getOrder() { return getGroup("orderFields"); },
  async setOrderCurrency(list) {
    const all = withDefaults(await fetchFields());
    all.orderFields.currency = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setOrderIntervals(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, value }]
    all.orderFields.intervals = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setOrderCategories(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, value, intervalId?, intervalValue? }]
    all.orderFields.categories = Array.isArray(list) ? list : [];
    return saveFields(all);
  },

  // ===== EXECUTOR =====
  async getExecutor() { return getGroup("executorFields"); },
  async setExecutorCurrency(list) {
    const all = withDefaults(await fetchFields());
    all.executorFields.currency = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setExecutorRoles(list) {
    const all = withDefaults(await fetchFields());
    all.executorFields.role = Array.isArray(list) ? list : [];
    return saveFields(all);
  },

  // ===== CLIENT =====
  async getClient() { return getGroup("clientFields"); },
  async setClientSources(list) {
    const all = withDefaults(await fetchFields());
    all.clientFields.source = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setClientCategories(list) {
    const all = withDefaults(await fetchFields());
    all.clientFields.category = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setClientCountries(list) {
    const all = withDefaults(await fetchFields());
    all.clientFields.country = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setClientCurrencies(list) {
    const all = withDefaults(await fetchFields());
    all.clientFields.currency = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setClientTags(list) {
    const all = withDefaults(await fetchFields());
    all.clientFields.tag = Array.isArray(list) ? list : [];
    return saveFields(all);
  },

  // ===== EMPLOYEE =====
  async getEmployee() { return getGroup("employeeFields"); },
  async setEmployeeCountries(list) {
    const all = withDefaults(await fetchFields());
    all.employeeFields.country = Array.isArray(list) ? list : [];
    return saveFields(all);
  },

  // ===== ASSETS =====
  async getAssets() { return getGroup("assetsFields"); },
  async setAssetsCurrency(list) {
    const all = withDefaults(await fetchFields());
    all.assetsFields.currency = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setAssetsTypes(list) {
    const all = withDefaults(await fetchFields());
    all.assetsFields.type = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setAssetsPaymentSystems(list) {
    const all = withDefaults(await fetchFields());
    all.assetsFields.paymentSystem = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setAssetsCardDesigns(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, name, url }]
    all.assetsFields.cardDesigns = Array.isArray(list) ? list : [];
    return saveFields(all);
  },

  // ===== FINANCE =====
  async getFinance() { return getGroup("financeFields"); },
  async setFinanceArticles(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, name }]
    all.financeFields.articles = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setFinanceSubarticles(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, name, articleId?, articleName?, subcategoryId?, subcategoryName? }]
    all.financeFields.subarticles = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
  async setFinanceSubcategory(list) {
    const all = withDefaults(await fetchFields());
    // ожидаем [{ id?, name }]
    all.financeFields.subcategory = Array.isArray(list) ? list : [];
    return saveFields(all);
  },
};

export default {
  fetchFields,
  saveFields,
  withDefaults,
  getGroup,
  setGroup,
  FieldsAPI,
};
