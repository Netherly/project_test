// src/api/transactions.js
import { httpGet, httpPost, httpPut, httpDelete } from "./http";

/** Универсальная распаковка { ok, data } или “голого” ответа */
const unwrap = (resp) => {
  if (resp && typeof resp === "object" && "ok" in resp) {
    if (resp.ok) return resp.data;
    const err = new Error(resp?.error || "Request failed");
    err.payload = resp;
    throw err;
  }
  return resp;
};

/** Собираем query-параметры без пустых значений */
const compactQuery = (q = {}) =>
  Object.fromEntries(
    Object.entries(q).filter(
      ([, v]) => v !== undefined && v !== null && v !== ""
    )
  );

/** Преобразуем строку 'YYYY-MM-DD HH:mm' -> ISO, иначе оставляем как есть */
const normalizeDateForSave = (date) => {
  if (!date) return date;
  if (typeof date === "string") {
    // поддержим оба формата: 'YYYY-MM-DD HH:mm' и 'YYYY-MM-DDTHH:mm'
    const iso = date.includes("T") ? date : date.replace(" ", "T");
    const d = new Date(iso);
    return isNaN(d.getTime()) ? date : iso; // пусть бэкенд сам парсит
  }
  if (date instanceof Date) return date.toISOString();
  return date;
};

/** Числовые поля -> число/строка, чтобы бэку было проще (Prisma Decimal) */
const normalizeNumbersForSave = (obj) => {
  if (!obj || typeof obj !== "object") return obj;
  const toDec = (v) =>
    v === "" || v === null || v === undefined ? undefined : Number(v);

  const out = { ...obj };
  // основные суммы
  if ("amount" in out) out.amount = toDec(out.amount);
  if ("commission" in out) out.commission = toDec(out.commission);

  // пересчёты
  if ("sumUAH" in out) out.sumUAH = toDec(out.sumUAH);
  if ("sumUSD" in out) out.sumUSD = toDec(out.sumUSD);
  if ("sumRUB" in out) out.sumRUB = toDec(out.sumRUB);

  if ("sumByRatesOrderAmountCurrency" in out)
    out.sumByRatesOrderAmountCurrency = toDec(out.sumByRatesOrderAmountCurrency);
  if ("sumByRatesUAH" in out) out.sumByRatesUAH = toDec(out.sumByRatesUAH);
  if ("sumByRatesUSD" in out) out.sumByRatesUSD = toDec(out.sumByRatesUSD);
  if ("sumByRatesRUB" in out) out.sumByRatesRUB = toDec(out.sumByRatesRUB);

  // балансы
  if ("balanceBefore" in out) out.balanceBefore = toDec(out.balanceBefore);
  if ("balanceAfter" in out) out.balanceAfter = toDec(out.balanceAfter);

  return out;
};

/** Нормализация перед отправкой на бэк: дата + числа */
const normalizeForSave = (payload) => {
  if (Array.isArray(payload)) {
    return payload.map((p) => {
      const x = { ...p };
      if ("date" in x) x.date = normalizeDateForSave(x.date);
      return normalizeNumbersForSave(x);
    });
  }
  const x = { ...payload };
  if ("date" in x) x.date = normalizeDateForSave(x.date);
  return normalizeNumbersForSave(x);
};

/**
 * Листинг
 * Бэкенд: либо { page, pageSize, total, items }, либо просто массив.
 * Вернём унифицированно: { items, page, pageSize, total }.
 */
export async function listTransactions(params = {}) {
  const {
    page = 1,
    pageSize = 200,
    search,
    accountId,
    clientId,
    companyId,
    dateFrom,
    dateTo,
  } = params;

  const resp = await httpGet(
    "/transactions",
    compactQuery({
      page,
      pageSize,
      search,
      accountId,
      clientId,
      companyId,
      dateFrom,
      dateTo,
    })
  );
  const data = unwrap(resp);

  if (Array.isArray(data)) {
    // массив без метаданных
    return { items: data, page, pageSize, total: data.length };
    }
  // объект с метой
  return {
    items: data.items || [],
    page: data.page ?? page,
    pageSize: data.pageSize ?? pageSize,
    total: data.total ?? (data.items ? data.items.length : 0),
  };
}

/** Получить по id */
export async function getTransactionById(id) {
  const resp = await httpGet(`/transactions/${id}`);
  return unwrap(resp);
}

/** Создать одну или массив (бэкенд принимает оба варианта) */
export async function createTransactions(payload /* obj | obj[] */) {
  const resp = await httpPost("/transactions", normalizeForSave(payload));
  return unwrap(resp);
}

/** Обновить по id */
export async function updateTransaction(id, data) {
  const resp = await httpPut(`/transactions/${id}`, normalizeForSave(data));
  return unwrap(resp);
}

/** Удалить по id */
export async function deleteTransaction(id) {
  const resp = await httpDelete(`/transactions/${id}`);
  return unwrap(resp);
}

/** Дублировать по id */
export async function duplicateTransaction(id) {
  const resp = await httpPost(`/transactions/${id}/duplicate`, {});
  return unwrap(resp);
}

export default {
  listTransactions,
  getTransactionById,
  createTransactions,
  updateTransaction,
  deleteTransaction,
  duplicateTransaction,
};
