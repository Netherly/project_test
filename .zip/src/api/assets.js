// src/api/assets.js
import { httpGet, httpPost, httpPatch, httpDelete } from './http';

/** Преобразуем decimal-строки из Prisma в числа для UI */
function numberizeAsset(asset) {
  if (!asset || typeof asset !== 'object') return asset;
  const numKeys = [
    'balance',
    'turnoverStartBalance',
    'turnoverIncoming',
    'turnoverOutgoing',
    'turnoverEndBalance',
    'balanceUAH',
  ];
  const copy = { ...asset };
  for (const k of numKeys) {
    if (copy[k] !== undefined && copy[k] !== null) {
      const v = Number(copy[k]);
      copy[k] = Number.isFinite(v) ? v : copy[k];
    }
  }
  return copy;
}
const numberizeMany = (list) => Array.isArray(list) ? list.map(numberizeAsset) : list;

const base = '/assets';

export const AssetsAPI = {
  /** GET /api/assets */
  async list(params = {}) {
    const data = await httpGet(base, params);
    return numberizeMany(data);
  },

  /** GET /api/assets/:id */
  async get(id) {
    const data = await httpGet(`${base}/${id}`);
    return numberizeAsset(data);
  },

  /** POST /api/assets */
  async create(payload) {
    const data = await httpPost(base, payload);
    return numberizeAsset(data);
  },

  /** PATCH /api/assets/:id */
  async update(id, payload) {
    const data = await httpPatch(`${base}/${id}`, payload);
    return numberizeAsset(data);
  },

  /** DELETE /api/assets/:id */
  async remove(id) {
    const data = await httpDelete(`${base}/${id}`);
    return numberizeAsset(data);
  },

  /** POST /api/assets/:id/duplicate */
  async duplicate(id) {
    const data = await httpPost(`${base}/${id}/duplicate`);
    return numberizeAsset(data);
  },

  /** PATCH /api/assets/:id/requisites */
  async upsertRequisites(id, requisites = []) {
    const data = await httpPatch(`${base}/${id}/requisites`, { requisites });
    return numberizeAsset(data);
  },

  /** POST /api/assets/recalc-month?companyId=... */
  async recalcMonth(companyId) {
    const qs = companyId ? `?companyId=${encodeURIComponent(companyId)}` : '';
    const data = await httpPost(`${base}/recalc-month${qs}`);
    return numberizeMany(data);
  },
};

export default AssetsAPI;
