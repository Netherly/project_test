// src/components/Assets/AssetCard.jsx
import React, { useState, useMemo } from 'react';
import '../../styles/AssetCard.css';

import visaLogo from '../../assets/assets-card/visa.png';
import mastercardLogo from '../../assets/assets-card/mastercard.png';
import mirLogo from '../../assets/assets-card/mir.png';
import cryptoLogo from '../../assets/assets-card/cryptologo.png';
import cardChip from '../../assets/assets-card/cardchip.png';
import { fileUrl } from '../../api/http';

const AssetCard = ({ asset, onCardClick, onCopyValue, onCopyRequisites }) => {
  const [isFlipped, setIsFlipped] = useState(false);

  // --- безопасные значения из объекта актива ---
  const currencyObj = asset?.currency && typeof asset.currency === 'object'
    ? asset.currency
    : null;
  const currencyCode = currencyObj?.code || (typeof asset?.currency === 'string' ? asset.currency : '');

  const paymentObj = asset?.paymentSystem && typeof asset.paymentSystem === 'object'
    ? asset.paymentSystem
    : null;
  const paymentName = paymentObj?.name || (typeof asset?.paymentSystem === 'string' ? asset.paymentSystem : '');

  // card design c бэка
  const cardDesignUrlRaw =
    asset?.cardDesign?.url ||
    asset?.cardDesignUrl ||
    asset?.cardDesign?.imageUrl ||
    '';
  const cardDesignUrl = cardDesignUrlRaw ? fileUrl(cardDesignUrlRaw) : '';

  // если нет картинки — используем классовый дизайн
  const hasImageDesign = !!cardDesignUrl;
  const designClass = !hasImageDesign
    ? asset?.design
      ? `card-design-${asset.design}`
      : 'card-design-default'
    : 'card-design-image';
  const backgroundStyle = hasImageDesign ? { backgroundImage: `url("${cardDesignUrl}")` } : {};

  const handleFlip = (e) => {
    e.stopPropagation();
    setIsFlipped((v) => !v);
  };

  const handleCopyClick = (e, value) => {
    e.stopPropagation();
    if (value) onCopyValue?.(value);
  };

  const cardNumber = asset?.requisites?.find((req) => req.label === 'Номер карты')?.value;
  const cardDate = asset?.requisites?.find((req) => req.label === 'Срок действия')?.value;
  const cardCVV = asset?.requisites?.find((req) => req.label === 'CVV')?.value;

  const handleCopyMainRequisite = (e) => {
    e.stopPropagation();
    if (asset?.requisites?.length) {
      const mainRequisite = cardNumber || asset.requisites[0]?.value || '';
      if (mainRequisite) onCopyValue?.(mainRequisite);
    }
  };

  const displayAccountName = useMemo(() => {
    const name = asset?.accountName || '';
    return name.includes('Binance') ? name.replace('Binance', 'CRYPTO') : name;
  }, [asset?.accountName]);

  const getCardTypeLogo = () => {
    const sys = paymentName;
    if (sys) {
      if (sys === 'Visa') return <img src={visaLogo} alt="Visa" className="card-type-logo visa" />;
      if (sys === 'Mastercard') return <img src={mastercardLogo} alt="Mastercard" className="card-type-logo mastercard" />;
      if (sys === 'Мир') return <img src={mirLogo} alt="Мир" className="card-type-logo mir" />;
      if (sys === 'Криптовалюта') return <img src={cryptoLogo} alt="Crypto" className="card-type-logo crypto" />;
    }
    if (cardNumber) {
      const s = String(cardNumber);
      if (s.startsWith('4')) return <img src={visaLogo} alt="Visa" className="card-type-logo visa" />;
      if (s.startsWith('5')) return <img src={mastercardLogo} alt="Mastercard" className="card-type-logo mastercard" />;
    }
    return null;
  };

  const getCurrencySymbol = (code) => {
    switch (code) {
      case 'UAH': return '₴';
      case 'USD': return '$';
      case 'RUB': return '₽';
      case 'EUR': return '€';
      case 'BTC': return '₿';
      case 'ETH': return 'Ξ';
      case 'USDT': return 'USDT';
      default: return code || '';
    }
  };

  const shouldShowCardElements = true;
  const balance = Number(asset?.balance || 0);

  return (
    <div
      className={`asset-card-wrapper ${isFlipped ? 'flipped' : ''} ${designClass}`}
      style={backgroundStyle}
      onClick={onCardClick}
    >
      <div className="asset-card-inner">
        {/* FRONT */}
        <div className="asset-card-front">
          <div className="card-top-left-name">
            <span className="asset-name-top-left">{displayAccountName}</span>
          </div>

          <div className="card-type-logo-container-top-right">
            {getCardTypeLogo()}
          </div>

          {shouldShowCardElements && (
            <img src={cardChip} alt="Card Chip" className="card-chip-logo-center-right" />
          )}

          <div className="card-balance-left-center">
            <span className="card-balance-value">
              {getCurrencySymbol(currencyCode)} {balance.toFixed(2)}
            </span>
          </div>

          <div className="card-free-balance-bottom-center">
            <span className="card-info-label">Свободный</span>
            <span className="card-info-value">{balance.toFixed(2)}</span>
          </div>

          <div className="card-bottom-right-actions">
            {asset?.requisites?.length > 0 &&
              (cardNumber || asset.requisites[0]?.value) && (
                <button
                  className="copy-main-requisite-button"
                  onClick={handleCopyMainRequisite}
                  title="Копировать основной реквизит"
                >
                  &#x2398;
                </button>
              )}
            <button className="flip-button" onClick={handleFlip} title="Показать реквизиты">
              &#x21C6;
            </button>
          </div>
        </div>

        {/* BACK */}
        <div className="asset-card-back">
          <div className="magnetic-stripe"></div>

          <div className="card-back-details">
            <div className="card-chip-container-back">
              {shouldShowCardElements && (
                <img src={cardChip} alt="Card Chip" className="card-chip-back" />
              )}
            </div>

            <div className="card-number-back-container">
              {cardNumber ? (
                <span
                  className="card-number-back"
                  onClick={(e) => handleCopyClick(e, cardNumber)}
                  title="Копировать номер карты"
                >
                  {cardNumber}
                </span>
              ) : (
                <span className="card-number-back empty"></span>
              )}
            </div>

            <div className="card-expiry-cvv">
              <div className="card-expiry">
                <span className="label">Срок</span>
                <span className="value">{cardDate || '--/--'}</span>
              </div>
              <div className="card-cvv">
                <span className="label">CVV</span>
                <span className="value">{cardCVV || '---'}</span>
              </div>
            </div>
          </div>

          <div className="card-bottom-right-actions-back">
            <button className="flip-button" onClick={handleFlip} title="Вернуться">
              &#x21C6;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssetCard;
