import React, { useState, useEffect, useCallback } from "react";
import Sidebar from "../Sidebar";
import "../../styles/AssetsPage.css";
import PageHeaderIcon from '../HeaderIcon/PageHeaderIcon.jsx';
import AddAssetForm from "./AddAssetForm";
import AssetDetailsModal from "./AssetDetailsModal";
import AssetCard from "./AssetCard";

// 👉 подключаем наш клиент API
import AssetsAPI from "../../api/assets";

const AssetsPage = () => {
  const [assets, setAssets] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [viewMode, setViewMode] = useState("table");
  const [fields, setFields] = useState({ currency: [], type: [], paymentSystem: [], cardDesigns: [] });
  const [cardSize, setCardSize] = useState("medium");
  const [loading, setLoading] = useState(false);

  // ===== Helpers =====

  // Найти id валюты по коду/имени (подстрой под свой справочник)
  const findCurrencyId = useCallback((value) => {
    if (!value) return null;
    const v = String(value).trim().toUpperCase();
    const byCode = fields.currency.find(c => (c.code || c.value)?.toString().toUpperCase() === v);
    if (byCode) return byCode.id || byCode.value || byCode.code; // любой UUID/ID
    const byName = fields.currency.find(c => (c.name || c.label)?.toString().toUpperCase() === v);
    return byName ? (byName.id || byName.value || byName.code) : null;
  }, [fields.currency]);

  const findByName = (list, value) => {
    if (!Array.isArray(list) || !value) return null;
    const v = String(value).trim().toLowerCase();
    const item = list.find(x =>
      [x.name, x.label, x.value]?.some(s => String(s || "").trim().toLowerCase() === v)
    );
    return item ? (item.id || item.value) : null;
  };

  const mapAddFormToPayload = useCallback((formAsset) => {
    // formAsset приходит из AddAssetForm — подстрой, если поля называются иначе
    const currencyId = formAsset.currencyId || findCurrencyId(formAsset.currency);
    const typeId = formAsset.typeId || findByName(fields.type, formAsset.type);
    const paymentSystemId = formAsset.paymentSystemId || findByName(fields.paymentSystem, formAsset.paymentSystem);
    const cardDesignId = formAsset.cardDesignId || findByName(fields.cardDesigns, formAsset.design);

    return {
      accountName: formAsset.accountName || formAsset.id || "Без названия",
      currencyId,                 // обязательно
      typeId: typeId || null,
      paymentSystemId: paymentSystemId || null,
      cardDesignId: cardDesignId || null,
      employeeId: formAsset.employeeId || null,
      companyId: formAsset.companyId || null,
      design: formAsset.design || null,
      balance: Number(formAsset.balance ?? 0),
      turnoverStartBalance: Number(formAsset.turnoverStartBalance ?? (formAsset.balance ?? 0)),
      requisites: Array.isArray(formAsset.requisites) ? formAsset.requisites : [],
    };
  }, [fields]);

  // ===== API actions =====

  const loadAssets = useCallback(async () => {
    setLoading(true);
    try {
      const data = await AssetsAPI.list();
      setAssets(data);
    } catch (e) {
      console.error("Не удалось загрузить активы:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // подхватим справочники из localStorage, если они там у тебя хранятся
    const savedFields = localStorage.getItem("fieldsData");
    if (savedFields) {
      try {
        const parsed = JSON.parse(savedFields);
        if (parsed.assetsFields) setFields(parsed.assetsFields);
      } catch (e) {
        console.error("Ошибка парсинга fieldsData:", e);
      }
    }
    // начальная загрузка активов
    loadAssets();
  }, [loadAssets]);

  const handleAddAsset = async (newAssetFromForm) => {
    try {
      const payload = mapAddFormToPayload(newAssetFromForm);
      if (!payload.currencyId) {
        alert("Не удалось определить currencyId. Проверьте выбранную валюту в форме.");
        return;
      }
      await AssetsAPI.create(payload);
      await loadAssets();
      setShowAddForm(false);
    } catch (e) {
      console.error("Ошибка при создании актива:", e);
      alert("Ошибка при создании актива. Подробнее в консоли.");
    }
  };

  const handleDeleteAsset = async (idToDelete) => {
    try {
      await AssetsAPI.remove(idToDelete);
      await loadAssets();
    } catch (e) {
      console.error("Ошибка при удалении актива:", e);
      alert("Ошибка при удалении.");
    }
  };

  const handleDuplicateAsset = async (asset) => {
    try {
      await AssetsAPI.duplicate(asset.id);
      await loadAssets();
    } catch (e) {
      console.error("Ошибка при дублировании:", e);
      alert("Ошибка при дублировании.");
    }
  };

  const handleSaveAsset = async (assetId, newRequisites) => {
    try {
      await AssetsAPI.upsertRequisites(assetId, newRequisites);
      await loadAssets();
    } catch (e) {
      console.error("Ошибка при сохранении реквизитов:", e);
      alert("Ошибка при сохранении реквизитов.");
    }
  };

  const handleCopyRequisites = (e, requisites) => {
    e.stopPropagation();
    if (requisites && requisites.length > 0) {
      const requisitesText = requisites.map(req => `${req.label}: ${req.value}`).join('\n');
      navigator.clipboard.writeText(requisitesText)
        .then(() => alert('Реквизиты скопированы!'))
        .catch(err => {
          console.error('Не удалось скопировать реквизиты: ', err);
          alert('Ошибка при копировании реквизитов.');
        });
    } else {
      alert('Реквизиты отсутствуют.');
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
      .then(() => alert('Скопировано!'))
      .catch(err => console.error('Не удалось скопировать: ', err));
  };

  const handleRowClick = (asset) => {
    setSelectedAsset(asset);
    setShowDetailsModal(true);
  };

  const handleCloseDetailsModal = () => {
    setShowDetailsModal(false);
    setSelectedAsset(null);
  };

  // ===== Витрина / агрегация =====

  // бэкенд присылает currency объект — берём code, fallback на строку
  const getCurrencyCode = (asset) => asset?.currency?.code || asset?.currency || "";

  const assetsByCurrency = assets.reduce((acc, asset) => {
    const code = getCurrencyCode(asset);
    if (!acc[code]) {
      acc[code] = {
        items: [],
        totalBalance: 0,
        totalBalanceUAH: 0,
        totalTurnoverStartBalance: 0,
        totalTurnoverIncoming: 0,
        totalTurnoverOutgoing: 0,
        totalTurnoverEndBalance: 0,
      };
    }
    acc[code].items.push(asset);
    acc[code].totalBalance += Number(asset.balance || 0);
    acc[code].totalBalanceUAH += Number(asset.balanceUAH || 0);
    acc[code].totalTurnoverStartBalance += Number(asset.turnoverStartBalance || 0);
    acc[code].totalTurnoverIncoming += Number(asset.turnoverIncoming || 0);
    acc[code].totalTurnoverOutgoing += Number(asset.turnoverOutgoing || 0);
    acc[code].totalTurnoverEndBalance += Number(asset.turnoverEndBalance || 0);
    return acc;
  }, {});

  const handleSetCardSize = (size) => setCardSize(size);

  return (
    <div className="assets-page">
      <Sidebar />
      <div className="assets-page-main-container">
        <header className="assets-header-container">
          <h1 className="assets-title">
            <PageHeaderIcon pageName="Активы" />
            Активы
          </h1>
          <div className="view-mode-buttons">
            <button
              className={`view-mode-button ${viewMode === 'card' ? 'active' : ''}`}
              onClick={() => setViewMode('card')}
              title="Карточный вид"
            >
              &#x25A3;
            </button>
            <button
              className={`view-mode-button ${viewMode === 'table' ? 'active' : ''}`}
              onClick={() => setViewMode('table')}
              title="Табличный вид"
            >
              &#x2261;
            </button>
          </div>
          <button className="add-asset-button" onClick={() => setShowAddForm(true)}>
            ➕ Добавить актив
          </button>
        </header>

        {viewMode === 'card' && (
          <div className="card-size-selector">
            <span>Размеры карт:</span>
            <button
              className={`card-size-button ${cardSize === 'large' ? 'active' : ''}`}
              onClick={() => handleSetCardSize('large')}
            >
              Крупно
            </button>
            <button
              className={`card-size-button ${cardSize === 'medium' ? 'active' : ''}`}
              onClick={() => handleSetCardSize('medium')}
            >
              Средне
            </button>
            <button
              className={`card-size-button ${cardSize === 'small' ? 'active' : ''}`}
              onClick={() => handleSetCardSize('small')}
            >
              Мелко
            </button>
          </div>
        )}

        <div className="assets-content">
          {loading && <div className="assets-loading">Загрузка...</div>}

          {!loading && viewMode === 'table' && (
            <div className="assets-table-container">
              <table className="assets-table assets-table-v2">
                <thead>
                  <tr>
                    <th rowSpan="2">Наименование актива</th>
                    <th rowSpan="2">Валюта</th>
                    <th rowSpan="2">Баланс</th>
                    <th rowSpan="2">Свободный</th>
                    <th rowSpan="2">Реквизиты</th>
                    <th colSpan="4" className="turnover-header">Оборот за текущий месяц</th>
                  </tr>
                  <tr>
                    <th>Баланс на нач.</th>
                    <th>Зачисления</th>
                    <th>Списания</th>
                    <th>Баланс на конец</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(assetsByCurrency).map(([currency, data], index) => (
                    <React.Fragment key={currency || `nc-${index}`}>
                      <tr className="currency-group-header">
                        <td colSpan="2">{currency || '—'}</td>
                        <td>{data.totalBalance.toFixed(2)}</td>
                        <td>{data.totalBalanceUAH.toFixed(2)}</td>
                        <td></td>
                        <td>{data.totalTurnoverStartBalance.toFixed(2)}</td>
                        <td>{data.totalTurnoverIncoming.toFixed(2)}</td>
                        <td>{data.totalTurnoverOutgoing.toFixed(2)}</td>
                        <td>{data.totalTurnoverEndBalance.toFixed(2)}</td>
                      </tr>
                      {data.items.map((asset) => (
                        <tr key={asset.id} className="asset-row" onClick={() => handleRowClick(asset)}>
                          <td>
                            <div className="account-info">
                              <span className="account-main-name">{asset.accountName}</span>
                              {/* если когда-то будет суб-id — выведем */}
                            </div>
                          </td>
                          <td>{getCurrencyCode(asset)}</td>
                          <td>{Number(asset.balance || 0).toFixed(2)}</td>
                          <td className={
                            Number(Number(asset.balance || 0).toFixed(2)) === Number(Number(asset.turnoverEndBalance || 0).toFixed(2))
                              ? 'highlight-green'
                              : 'highlight-red'
                          }>
                            {Number(asset.balance || 0).toFixed(2)}
                          </td>
                          <td>
                            <div className="copy-button-container" onClick={(e) => e.stopPropagation()}>
                              <span
                                className="copy-button-icon"
                                onClick={(e) => handleCopyRequisites(e, asset.requisites)}
                                title="Копировать реквизиты"
                              ></span>
                            </div>
                          </td>
                          <td>{Number(asset.turnoverStartBalance || 0).toFixed(2)}</td>
                          <td>{Number(asset.turnoverIncoming || 0).toFixed(2)}</td>
                          <td>{Number(asset.turnoverOutgoing || 0).toFixed(2)}</td>
                          <td>{Number(asset.turnoverEndBalance || 0).toFixed(2)}</td>
                        </tr>
                      ))}
                      {index < Object.keys(assetsByCurrency).length - 1 && (
                        <tr className="table-section-divider">
                          <td colSpan="9"></td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {!loading && viewMode === 'card' && (
            <div className={`assets-cards-container card-size-${cardSize}`}>
              {Object.entries(assetsByCurrency).map(([currency, data]) => (
                <div key={currency} className="currency-card-group">
                  <div className="currency-card-header">
                    <span className="currency-name-card">{currency}</span>
                    <span className="total-in-currency-сard">{data.totalBalance.toFixed(2)}</span>
                    <span className="total-from-settings-сard">{data.totalBalanceUAH.toFixed(2)}</span>
                  </div>
                  <div className="currency-card-items">
                    {data.items.map(asset => (
                      <AssetCard
                        key={asset.id}
                        asset={asset}
                        onCardClick={() => handleRowClick(asset)}
                        onCopyValue={copyToClipboard}
                        onCopyRequisites={(e) => handleCopyRequisites(e, asset.requisites)}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {showAddForm && (
          <AddAssetForm
            onClose={() => setShowAddForm(false)}
            onAdd={handleAddAsset}
            fields={fields}
          />
        )}

        {showDetailsModal && selectedAsset && (
          <AssetDetailsModal
            asset={selectedAsset}
            onClose={handleCloseDetailsModal}
            onDelete={() => handleDeleteAsset(selectedAsset.id)}
            onDuplicate={() => handleDuplicateAsset(selectedAsset)}
            onSave={handleSaveAsset}
          />
        )}
      </div>
    </div>
  );
};

export default AssetsPage;
