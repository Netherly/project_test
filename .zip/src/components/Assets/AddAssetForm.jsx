import React, { useEffect, useMemo, useState } from 'react';
import '../../styles/AddAssetForm.css';

// API полей
import { FieldsAPI } from '../../api/fields';

const designNameMap = {
  'Монобанк': 'monobank-black',
  'ПриватБанк': 'privatbank-green',
  'Сбербанк': 'sберbank-light-green',
  'Bybit': 'bybit-white',
  'Рубин': 'ruby',
  'Сапфир': 'saphire',
  'Атлас': 'atlas',
  '3Д': '3d',
  'Красный': 'red',
};

// нормализуем элементы в { id, label, raw }
function toOptions(list, kind) {
  if (!Array.isArray(list)) return [];
  return list
    .map((x) => {
      if (x == null) return null;

      if (typeof x === 'string') {
        // если внезапно пришли строки — делаем временный вариант без id
        return { id: x, label: x, raw: x };
      }

      // backend getAll() для assetsFields:
      // currency:     { id, code, name }
      // type:         { id, name }
      // paymentSystem:{ id, name }
      // cardDesigns:  { id, name, url }
      const id = x.id ?? null;

      // метка: для валют — code (если есть), иначе name/value/label
      let label =
        (kind === 'currency' ? (x.code || x.name) : null) ||
        x.name ||
        x.value ||
        x.label ||
        x.code ||
        x.id;

      if (!id && !label) return null;
      return { id, label: String(label), raw: x };
    })
    .filter(Boolean);
}

const AddAssetForm = ({ onAdd, onClose, fields }) => {
  const [activeTab, setActiveTab] = useState('general');

  // локальный слепок словарей для формы
  const [assetsFields, setAssetsFields] = useState({
    currency: [],
    type: [],
    paymentSystem: [],
    cardDesigns: [],
  });

  // при открытии — тянем с бэка актуальные словари
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const af = await FieldsAPI.getAssets(); // { currency, type, paymentSystem, cardDesigns }
        if (!mounted) return;
        setAssetsFields({
          currency: Array.isArray(af?.currency) ? af.currency : [],
          type: Array.isArray(af?.type) ? af.type : [],
          paymentSystem: Array.isArray(af?.paymentSystem) ? af.paymentSystem : [],
          cardDesigns: Array.isArray(af?.cardDesigns) ? af.cardDesigns : [],
        });
      } catch (e) {
        console.error('Не удалось получить assetsFields:', e);
        // если что-то пошло не так — оставляем пустые списки
        setAssetsFields({ currency: [], type: [], paymentSystem: [], cardDesigns: [] });
      }
    })();
    return () => { mounted = false; };
  }, []);

  // строим опции с id
  const currencyOpts = useMemo(() => toOptions(assetsFields.currency, 'currency'), [assetsFields.currency]);
  const typeOpts = useMemo(() => toOptions(assetsFields.type, 'type'), [assetsFields.type]);
  const paymentOpts = useMemo(() => toOptions(assetsFields.paymentSystem, 'payment'), [assetsFields.paymentSystem]);
  const designOpts = useMemo(() => toOptions(assetsFields.cardDesigns, 'design'), [assetsFields.cardDesigns]);

  const [formData, setFormData] = useState({
    accountName: '',
    currencyId: '',
    typeId: '',
    paymentSystemId: '',
    cardDesignId: '',
    design: '', // css-класс для твоего карточного вида
    employee: '',
    requisites: [{ label: '', value: '' }],
    limitTurnover: '',
  });

  // после загрузки опций — подставляем дефолты, если ещё не выбраны
  useEffect(() => {
    setFormData((prev) => {
      const next = { ...prev };
      if (!next.currencyId && currencyOpts[0]?.id) next.currencyId = currencyOpts[0].id;
      if (!next.typeId && typeOpts[0]?.id) next.typeId = typeOpts[0].id;
      if (!next.paymentSystemId && paymentOpts[0]?.id) next.paymentSystemId = paymentOpts[0].id;
      if (!next.cardDesignId && designOpts[0]?.id) {
        next.cardDesignId = designOpts[0].id;
        next.design = designNameMap[designOpts[0]?.label] || next.design || '';
      }
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currencyOpts.length, typeOpts.length, paymentOpts.length, designOpts.length]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((p) => ({ ...p, [name]: value }));
  };

  const handleRequisiteChange = (index, e) => {
    const { name, value } = e.target;
    setFormData((p) => {
      const next = [...p.requisites];
      next[index] = { ...next[index], [name]: value };
      return { ...p, requisites: next };
    });
  };

  const handleAddRequisite = () => {
    setFormData((p) => ({ ...p, requisites: [...p.requisites, { label: '', value: '' }] }));
  };

  const handleRemoveRequisite = (index) => {
    setFormData((p) => {
      const next = p.requisites.filter((_, i) => i !== index);
      return { ...p, requisites: next.length ? next : [{ label: '', value: '' }] };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // валидация: обязательно нужен currencyId
    if (!formData.currencyId) {
      alert('Выберите валюту счета');
      return;
    }

    const filteredRequisites = (formData.requisites || [])
      .filter(r => (r.label?.trim() || r.value?.trim()))
      .map(r => ({ label: r.label.trim(), value: r.value.trim() }));

    // payload строго под бэкенд — с ID
    const payload = {
      accountName: formData.accountName,
      currencyId: formData.currencyId,               // ID из словаря
      typeId: formData.typeId || null,               // ID
      paymentSystemId: formData.paymentSystemId || null, // ID
      cardDesignId: formData.cardDesignId || null,   // ID
      design: formData.design || null,               // необязательно, css-класс для фронта
      balance: 0,
      turnoverStartBalance: 0,
      requisites: filteredRequisites,
      // employeeId/companyId — добавишь, если надо
    };

    onAdd(payload);
    onClose();
  };

  return (
    <div className="add-asset-overlay">
      <div className="add-asset-modal">
        <div className="add-asset-header">
          <h2>Добавить счет</h2>
          <div className="add-asset-actions">
            <span className="icon" onClick={onClose}>✖️</span>
          </div>
        </div>

        <div className="tabs">
          <button
            className={`tab-button ${activeTab === 'general' ? 'active' : ''}`}
            onClick={() => setActiveTab('general')}
          >
            Общая информация
          </button>
          <button
            className={`tab-button ${activeTab === 'requisites' ? 'active' : ''}`}
            onClick={() => setActiveTab('requisites')}
          >
            Реквизиты
          </button>
        </div>

        <form onSubmit={handleSubmit} className="add-asset-form">
          {activeTab === 'general' && (
            <div className="tab-content">
              <div className="form-row">
                <label htmlFor="accountName" className="form-label">Наименование счета</label>
                <input
                  type="text"
                  id="accountName"
                  name="accountName"
                  value={formData.accountName}
                  onChange={handleChange}
                  placeholder="Например, ПриватБанк - Ключ к счету"
                  required
                  className="form-input"
                />
              </div>

              <div className="form-row">
                <label htmlFor="currencyId" className="form-label">Валюта счета</label>
                <select
                  id="currencyId"
                  name="currencyId"
                  value={formData.currencyId}
                  onChange={handleChange}
                  required
                  className="form-input"
                >
                  <option value="" disabled>Выберите валюту</option>
                  {currencyOpts.map((opt) => (
                    <option key={opt.id ?? opt.label} value={opt.id ?? ''}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-row">
                <label htmlFor="typeId" className="form-label">Тип</label>
                <select
                  id="typeId"
                  name="typeId"
                  value={formData.typeId}
                  onChange={handleChange}
                  className="form-input"
                >
                  <option value="">Не выбрано</option>
                  {typeOpts.map((opt) => (
                    <option key={opt.id ?? opt.label} value={opt.id ?? ''}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-row">
                <label htmlFor="paymentSystemId" className="form-label">Платежная система</label>
                <select
                  id="paymentSystemId"
                  name="paymentSystemId"
                  value={formData.paymentSystemId}
                  onChange={handleChange}
                  className="form-input"
                >
                  <option value="">Не выбрано</option>
                  {paymentOpts.map((opt) => (
                    <option key={opt.id ?? opt.label} value={opt.id ?? ''}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-row">
                <label htmlFor="cardDesignId" className="form-label">Дизайн</label>
                <select
                  id="cardDesignId"
                  name="cardDesignId"
                  value={formData.cardDesignId}
                  onChange={(e) => {
                    const nextId = e.target.value;
                    const found = designOpts.find(d => String(d.id) === String(nextId));
                    setFormData((p) => ({
                      ...p,
                      cardDesignId: nextId,
                      design: designNameMap[found?.label] || p.design || '',
                    }));
                  }}
                  className="form-input"
                >
                  <option value="">Не выбрано</option>
                  {designOpts.map((opt) => (
                    <option key={opt.id ?? opt.label} value={opt.id ?? ''}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-row">
                <label htmlFor="employee" className="form-label">Сотрудник (текстом)</label>
                <input
                  type="text"
                  id="employee"
                  name="employee"
                  value={formData.employee}
                  onChange={handleChange}
                  placeholder="Опционально"
                  className="form-input"
                />
              </div>
            </div>
          )}

          {activeTab === 'requisites' && (
            <div className="tab-content">
              {formData.requisites.map((req, index) => (
                <div key={index} className="requisite-item">
                  <div className="form-row-inner">
                    <label className="form-label">Название:</label>
                    <input
                      type="text"
                      name="label"
                      value={req.label}
                      onChange={(e) => handleRequisiteChange(index, e)}
                      placeholder="Например, Ключ к счету"
                      className="form-input"
                    />
                  </div>
                  <div className="form-row-inner">
                    <label className="form-label">Значение:</label>
                    <input
                      type="text"
                      name="value"
                      value={req.value}
                      onChange={(e) => handleRequisiteChange(index, e)}
                      placeholder="Введите значение"
                      className="form-input"
                    />
                  </div>
                  {formData.requisites.length > 1 && (
                    <button
                      type="button"
                      className="remove-requisite-button"
                      onClick={() => handleRemoveRequisite(index)}
                    >
                      Удалить
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                className="add-requisite-button"
                onClick={handleAddRequisite}
              >
                Добавить еще реквизит
              </button>
            </div>
          )}

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>Отменить</button>
            <button type="submit" className="save-button">Сохранить</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddAssetForm;
