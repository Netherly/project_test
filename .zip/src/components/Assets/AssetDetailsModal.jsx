import React, { useState, useEffect, useRef } from 'react';
import '../../styles/AssetDetailsModal.css';

// опционально используем прямой вызов бэка, если родитель не передал onSave
import { AssetsAPI } from '../../api/assets'; // убедись, что такой модуль есть (create/update/upsertRequisites)

const n2 = (v) => Number.isFinite(+v) ? Number(v).toFixed(2) : Number(0).toFixed(2);
const num = (v, d = 0) => Number.isFinite(+v) ? +v : d;

const getCurrencyLabel = (cur) => {
  if (!cur) return '';
  if (typeof cur === 'string') return cur;
  // поддержка объектов от бэка { code, name }
  return cur.code || cur.name || '';
};

const getPaymentSystemLabel = (p) => {
  if (!p) return '';
  if (typeof p === 'string') return p;
  return p.name || '';
};

const AssetDetailsModal = ({ asset, onClose, onDelete, onDuplicate, onSave }) => {
  const [showPaymentSystem, setShowPaymentSystem] = useState(false);
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [exchangeRates, setExchangeRates] = useState(null);
  const [showTurnoverTooltip, setShowTurnoverTooltip] = useState(false);
  const [isEditingMainRequisite, setIsEditingMainRequisite] = useState(false);
  const [currentRequisites, setCurrentRequisites] = useState(asset?.requisites || []);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  const dragItem = useRef(null);
  const dragOverItem = useRef(null);

  useEffect(() => {
    // курсы — как было, с фолбэком
    try {
      const raw = localStorage.getItem('exchangeRates');
      const list = raw ? JSON.parse(raw) : null;
      if (Array.isArray(list) && list.length > 0) {
        setExchangeRates(list[0]);
      } else {
        setExchangeRates({
          UAH: 1,
          USD: 43,
          RUB: 0.5,
          UAH_RUB: 2,
          UAH_USD: 1 / 43,
          USD_UAH: 43,
          USD_RUB: 16.0004,
          RUB_UAH: 0.5,
          RUB_USD: 1 / 16.0004,
        });
      }
    } catch {
      setExchangeRates({
        UAH: 1,
        USD: 43,
        RUB: 0.5,
        UAH_RUB: 2,
        UAH_USD: 1 / 43,
        USD_UAH: 43,
        USD_RUB: 16.0004,
        RUB_UAH: 0.5,
        RUB_USD: 1 / 16.0004,
      });
    }
  }, []);

  useEffect(() => {
    setCurrentRequisites(asset?.requisites || []);
  }, [asset?.requisites]);

  if (!asset || !exchangeRates) return null;

  const currencyLabel = getCurrencyLabel(asset.currency) || asset.currencyCode || asset.currencyName || '';
  const paymentSystemLabel = getPaymentSystemLabel(asset.paymentSystem) || asset.paymentSystemName || asset.type || '';

  const mainRequisite = currentRequisites[0] || null;
  const otherRequisites = currentRequisites.slice(1);

  const currentTurnoverIncoming = num(asset.turnoverIncoming, 0);
  const currentTurnoverOutgoing = num(asset.turnoverOutgoing, 0);
  const totalCurrentTurnover = currentTurnoverIncoming + currentTurnoverOutgoing;

  // если из бэка придёт лимит — используем его, иначе 1000 как раньше
  const turnoverLimit = num(asset.limitTurnover, 1000) || 1000;
  const turnoverPercentage = turnoverLimit > 0 ? (totalCurrentTurnover / turnoverLimit) * 100 : 0;
  const formattedTurnoverPercentage = Math.min(100, Math.max(0, turnoverPercentage)).toFixed(2);

  const handleMenuToggle = () => setShowOptionsMenu((p) => !p);

  const handleDeleteClick = () => {
    if (window.confirm(`Вы уверены, что хотите удалить актив "${asset.accountName || asset.name || ''}"?`)) {
      onDelete?.(asset.id);
      onClose?.();
    }
    setShowOptionsMenu(false);
  };

  const handleDuplicateClick = () => {
    onDuplicate?.(asset);
    onClose?.();
    setShowOptionsMenu(false);
  };

  const convertToCurrency = (amount, fromCurrencyCode, toCurrencyCode) => {
    const a = num(amount, 0);
    const from = fromCurrencyCode || 'UAH';
    const to = toCurrencyCode || 'UAH';

    if (!exchangeRates) return n2(a);
    if (from === to) return n2(a);

    // сначала в UAH
    let inUAH = a;
    if (from !== 'UAH') {
      const k = `${from}_UAH`;
      if (exchangeRates[k]) inUAH = a * exchangeRates[k];
      else return n2(a);
    }
    if (to === 'UAH') return n2(inUAH);

    const k2 = `UAH_${to}`;
    if (exchangeRates[k2]) return n2(inUAH * exchangeRates[k2]);
    return n2(a);
  };

  const currentBalance = num(asset.balance, 0);
  const freeBalance = Number.isFinite(asset.freeBalance) ? num(asset.freeBalance, 0) : currentBalance;

  const handleDragStart = (e, index) => {
    dragItem.current = index;
    e.dataTransfer.effectAllowed = 'move';
    e.currentTarget.classList.add('dragging');
  };
  const handleDragEnter = (e, index) => {
    dragOverItem.current = index;
    e.currentTarget.classList.add('drag-over');
  };
  const handleDragLeave = (e) => {
    e.currentTarget.classList.remove('drag-over');
  };
  const handleDragEnd = (e) => {
    e.currentTarget.classList.remove('dragging');
    document.querySelectorAll('.drag-over').forEach((el) => el.classList.remove('drag-over'));
  };
  const allowDrop = (e) => e.preventDefault();

  const handleDrop = (e) => {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');

    const fromIdx = dragItem.current;
    const toIdx = dragOverItem.current;
    if (fromIdx == null || toIdx == null || fromIdx === toIdx) return;

    const next = [...currentRequisites];
    const [moved] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, moved);
    setCurrentRequisites(next);
    setIsEditingMainRequisite(false);
    dragItem.current = null;
    dragOverItem.current = null;
  };

  const doSave = async () => {
    setSaving(true);
    setSaveError('');
    try {
      const cleanReqs = (currentRequisites || [])
        .filter((r) => (r?.label?.trim() || r?.value?.trim()))
        .map((r) => ({ label: r.label.trim(), value: r.value.trim() }));

      if (typeof onSave === 'function') {
        await onSave(asset.id, cleanReqs);
      } else if (AssetsAPI?.upsertRequisites) {
        await AssetsAPI.upsertRequisites(asset.id, cleanReqs);
      }
      onClose?.();
    } catch (e) {
      console.error(e);
      setSaveError(e?.message || 'Не удалось сохранить изменения.');
    } finally {
      setSaving(false);
    }
  };

  const tStart = n2(asset.turnoverStartBalance);
  const tIn = n2(asset.turnoverIncoming);
  const tOut = n2(asset.turnoverOutgoing);
  const tEnd = n2(asset.turnoverEndBalance);

  const currCode = currencyLabel || 'UAH';

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2>Актив "{asset.accountName || asset.name || ''}"</h2>
          <div className="header-actions-right">
            <span>{currCode}</span>
            <div className="modal-header-actions">
              <button className="options-button" onClick={handleMenuToggle} aria-label="Опции">&#x22EF;</button>
              {showOptionsMenu && (
                <div className="options-menu">
                  <button className="menu-item" onClick={handleDuplicateClick}>Дублировать актив</button>
                  <button className="menu-item delete-item" onClick={handleDeleteClick}>Удалить актив</button>
                </div>
              )}
              <button className="modal-close-button" onClick={onClose} aria-label="Закрыть">&times;</button>
            </div>
          </div>
        </div>

        <div className="modal-body1 custom-scrollbar">
          <div className="modal-section">
            <h3>Баланс</h3>
            <div className="balance-grid-header">
              <span>{currCode}</span>
              <span>В грн</span>
              <span>В $</span>
              <span>В руб</span>
            </div>
            <div className="balance-grid-row">
              <span>{n2(currentBalance)}</span>
              <span>{convertToCurrency(currentBalance, currCode, 'UAH')}</span>
              <span>{convertToCurrency(currentBalance, currCode, 'USD')}</span>
              <span>{convertToCurrency(currentBalance, currCode, 'RUB')}</span>
            </div>
          </div>

          <div className="modal-section">
            <h3>Свободный</h3>
            <div className="balance-grid-header">
              <span>{currCode}</span>
              <span>В грн</span>
              <span>В $</span>
              <span>В руб</span>
            </div>
            <div className="balance-grid-row">
              <span className={num(freeBalance) === num(asset.turnoverEndBalance) ? 'highlight-green' : ''}>
                {n2(freeBalance)}
              </span>
              <span className={num(freeBalance) === num(asset.turnoverEndBalance) ? 'highlight-green' : ''}>
                {convertToCurrency(freeBalance, currCode, 'UAH')}
              </span>
              <span className={num(freeBalance) === num(asset.turnoverEndBalance) ? 'highlight-green' : ''}>
                {convertToCurrency(freeBalance, currCode, 'USD')}
              </span>
              <span className={num(freeBalance) === num(asset.turnoverEndBalance) ? 'highlight-green' : ''}>
                {convertToCurrency(freeBalance, currCode, 'RUB')}
              </span>
            </div>
          </div>

          <div className="modal-section">
            <h3>Лимит оборота</h3>
            <div
              className="modal-limit-input-container"
              onMouseEnter={() => setShowTurnoverTooltip(true)}
              onMouseLeave={() => setShowTurnoverTooltip(false)}
            >
              <div className="modal-limit-progress-bar-wrapper">
                <div
                  className="modal-limit-progress-bar"
                  style={{ width: `${formattedTurnoverPercentage}%` }}
                />
              </div>
              <span className="modal-limit-value">{formattedTurnoverPercentage}%</span>
              {showTurnoverTooltip && (
                <div className="turnover-tooltip">
                  Зачислено: {n2(currentTurnoverIncoming)} / Списано: {n2(currentTurnoverOutgoing)}
                </div>
              )}
            </div>
          </div>

          <div className="modal-buttons-group">
            <button className="modal-button-outline">Дизайн карты</button>
            <button
              className="modal-button-outline"
              onClick={() => setShowPaymentSystem((p) => !p)}
            >
              Платежная система
            </button>
          </div>

          {showPaymentSystem && (
            <div className="payment-system-display">
              <p><strong>Платежная система:</strong> {paymentSystemLabel}</p>
            </div>
          )}

          <div className="modal-section main-requisite-block">
            <h3>Основной реквизит</h3>
            {mainRequisite ? (
              <div
                className={`main-requisite-item ${isEditingMainRequisite ? 'editable' : ''}`}
                draggable={isEditingMainRequisite}
                onDragStart={(e) => handleDragStart(e, 0)}
                onDragEnter={(e) => handleDragEnter(e, 0)}
                onDragLeave={handleDragLeave}
                onDragEnd={handleDragEnd}
                onDrop={handleDrop}
                onDragOver={allowDrop}
              >
                <label>{mainRequisite.label}</label>
                <span>{mainRequisite.value}</span>
                <button
                  className="edit-requisite-button"
                  onClick={() => setIsEditingMainRequisite((p) => !p)}
                  title={isEditingMainRequisite ? 'Завершить редактирование' : 'Редактировать основной реквизит'}
                >
                  {isEditingMainRequisite ? '✖' : '✎'}
                </button>
              </div>
            ) : (
              <p>Основной реквизит не указан.</p>
            )}
          </div>

          <div className="modal-section requisites-block">
            <h3>Дополнительные реквизиты</h3>
            {otherRequisites.length > 0 ? (
              <div className="other-requisites-list">
                {otherRequisites.map((item, index) => (
                  <div
                    key={item.id || index}
                    className={`other-requisite-item ${isEditingMainRequisite ? 'editable' : ''}`}
                    draggable={isEditingMainRequisite}
                    onDragStart={(e) => handleDragStart(e, index + 1)}
                    onDragEnter={(e) => handleDragEnter(e, index + 1)}
                    onDragLeave={handleDragLeave}
                    onDragEnd={handleDragEnd}
                    onDrop={handleDrop}
                    onDragOver={allowDrop}
                  >
                    <label>{item.label}</label>
                    <span>{item.value}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p>Дополнительные реквизиты не указаны.</p>
            )}
          </div>

          <div className="modal-section turnover-section">
            <h3>Оборот за текущий месяц</h3>
            <div className="turnover-table">
              <div className="turnover-table-header">
                <span>Баланс на начал.</span>
                <span>Зачисления</span>
                <span>Списания</span>
                <span>Баланс на конец</span>
              </div>
              <div className="turnover-table-row">
                <span>{tStart}</span>
                <span>{tIn}</span>
                <span>{tOut}</span>
                <span>{tEnd}</span>
              </div>
            </div>
          </div>

          {saveError && <div className="modal-error">{saveError}</div>}
        </div>

        <div className="modal-footer">
          <button className="modal-cancel-button" onClick={onClose} disabled={saving}>Отменить</button>
          <button className="modal-save-button" onClick={doSave} disabled={saving}>
            {saving ? 'Сохранение…' : 'Сохранить'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssetDetailsModal;
