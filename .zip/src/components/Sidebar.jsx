// src/components/Sidebar.jsx
import { NavLink, useLocation } from "react-router-dom";
import React, { useState, useCallback, useEffect, useRef, memo } from "react";
import Lottie from "lottie-react";
import "../styles/Sidebar.css";

// /* ====== Импорты медиа ====== */
// import DashboardWebm from "../assets/menu-icons/Дашборд.webм";
import FinanceWebm from "../assets/menu-icons/Финансы.webm";
import DirectoryWebm from "../assets/menu-icons/Справочники.webm";
import DesktopWebm from "../assets/menu-icons/Рабочий стол.webm";
import FieldSettingsWebm from "../assets/menu-icons/Настройки полей.webm";
import CurrencyRatesWebm from "../assets/menu-icons/Курсы валют.webm";
import ClientsWebm from "../assets/menu-icons/Клиенты.webm";
import OrdersWebm from "../assets/menu-icons/Заказы.webm";
// import AssetsWebm from "../assets/menu-icons/Активы.webm";
// import AssetsNewWebm from "../assets/menu-icons/Активы вектор вебм.webm";
import TasksWebm from "../assets/menu-icons/Задачи.webm";
import RolesWebm from "../assets/menu-icons/Роли.webm";
import EntryWebm from "../assets/menu-icons/Доступы.webm";
import ArchiveWebm from "../assets/menu-icons/Архив.webm";
import ExecutorsWebm from "../assets/menu-icons/Исполнители.webm";
import SettingsWebm from "../assets/menu-icons/Настройки.webm";
import JournalWebm from "../assets/menu-icons/Журнал.webm";
import TransactionWebm from "../assets/menu-icons/Транзакции.webm";
import TransactionNewWebm from "../assets/menu-icons/Транзакции вектор вебм.webm";
import ReportWebm from "../assets/menu-icons/Отчеты.webm";
import EmployesWebm from "../assets/menu-icons/Сотрудники.webm";

import TransactionJson from "../assets/menu-icons/транзакциии json.json";
import AssetsNewJson from "../assets/menu-icons/активы json.json";
import DashboardJson from "../assets/menu-icons/дашборд json.json";

/* ========= Ленивая иконка ========= */

const MediaIcon = memo(function MediaIcon({ src, alt, className }) {
  const containerRef = useRef(null);
  const [visible, setVisible] = useState(false);
  const [prefersReduce, setPrefersReduce] = useState(false);

  useEffect(() => {
    // prefers-reduced-motion => не проигрываем анимации
    const m = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (m) {
      const apply = () => setPrefersReduce(!!m.matches);
      apply();
      m.addEventListener?.("change", apply);
      return () => m.removeEventListener?.("change", apply);
    }
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      entries => {
        entries.forEach(e => setVisible(e.isIntersecting));
      },
      { rootMargin: "120px" } // подгружаем заранее
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // webm-видео
  if (typeof src === "string" && src.endsWith(".webm")) {
    return (
      <div ref={containerRef} className={className} style={{ display: "inline-flex" }}>
        {visible && !prefersReduce ? (
          <video
            src={src}
            autoPlay
            loop
            muted
            playsInline
            preload="none"
            controls={false}
            disablePictureInPicture
            style={{ width: "100%", height: "100%", display: "block" }}
          />
        ) : (
          <span aria-hidden style={{ width: "1em", height: "1em" }} />
        )}
      </div>
    );
  }

  // Lottie (JSON)
  if (typeof src === "object" && src !== null) {
    return (
      <div ref={containerRef} className={className} style={{ display: "inline-flex" }}>
        {visible && !prefersReduce ? (
          <Lottie animationData={src} loop autoplay />
        ) : (
          <span aria-hidden style={{ width: "1em", height: "1em" }} />
        )}
      </div>
    );
  }

  // Картинки
  return (
    <img
      ref={containerRef}
      src={src}
      alt={alt}
      className={className}
      loading="lazy"
      decoding="async"
      // при желании: width/height для предотвращения layout shift
    />
  );
});

/* ========= Sidebar ========= */

const Sidebar = () => {
  const location = useLocation();
  const [activeMenu, setActiveMenu] = useState(null);

  const submenus = {
    Desktop: [
      { name: "Заказы", path: "/orders", icon: OrdersWebm },
      { name: "Исполнители", path: "/executors", icon: ExecutorsWebm },
      { name: "Задачи", path: "/tasks", icon: TasksWebm },
      { name: "Журнал", path: "/journal", icon: JournalWebm },
      { name: "Календарь", path: "/calendar" },
    ],
    directory: [
      { name: "Клиенты", path: "/clients", icon: ClientsWebm },
      { name: "Сотрудники", path: "/employees", icon: EmployesWebm },
      { name: "Отчёты", path: "/reports", icon: ReportWebm },
      { name: "Доступы", path: "/access", icon: EntryWebm },
    ],
    transactions: [
      { name: "Активы", path: "/assets", icon: AssetsNewJson },
      { name: "Транзакции", path: "/list", icon: TransactionJson },
    ],
    settings: [
      { name: "Роли/Доступы", path: "/roles-access", icon: RolesWebm },
      { name: "Настройки полей", path: "/fields", icon: FieldSettingsWebm },
      { name: "Курс валют", path: "/currency-rates", icon: CurrencyRatesWebm },
    ],
  };

  const mainMenuItems = [
    { name: "Дашборд", path: "/home", exact: "/statistics", iconActive: DashboardJson, iconInactive: DashboardJson },
    { name: "Рабочий стол", menu: "Desktop", iconActive: DesktopWebm, iconInactive: DesktopWebm },
    { name: "Финансы", menu: "transactions", iconActive: FinanceWebm, iconInactive: FinanceWebm },
    { name: "Справочник", menu: "directory", iconActive: DirectoryWebm, iconInactive: DirectoryWebm },
    { name: "Архив", path: "/archive", iconActive: ArchiveWebm, iconInactive: ArchiveWebm },
    { name: "Настройки", menu: "settings", iconActive: SettingsWebm, iconInactive: SettingsWebm },
  ];

  const MouseEnter = useCallback((menuName) => setActiveMenu(menuName), []);
  const MouseLeave = useCallback(() => setActiveMenu(null), []);
  const isActivePath = useCallback((path) => location.pathname === path, [location.pathname]);

  const isParentMenuActive = useCallback(
    (menuKey) => {
      if (!submenus[menuKey]) return false;
      return submenus[menuKey].some((submenuItem) => location.pathname === submenuItem.path);
    },
    [location.pathname]
  );

  const copyClientId = useCallback((clientId) => {
    navigator.clipboard
      .writeText(clientId)
      .then(() => console.log("ID клиента скопировано:", clientId))
      .catch((err) => console.error("Ошибка копирования:", err));
  }, []);

  const clientId = "23995951";

  const renderSubmenu = useCallback(
    (key) => {
      if (!submenus[key]) return null;
      return (
        <div
          key={`submenu-${key}`}
          className="submenu-panel show"
          onMouseEnter={() => MouseEnter(key)}
          onMouseLeave={MouseLeave}
        >
          <ul className="submenu">
            {submenus[key].map(({ name, path, icon }) => (
              <li key={`${key}-${path}`}>
                <NavLink to={path} onClick={() => setActiveMenu(null)}>
                  {icon && <MediaIcon src={icon} alt={name} className="submenu-icon" />}
                  <span>{name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      );
    },
    [MouseEnter, MouseLeave]
  );

  return (
    <>
      <nav className="sidebar">
        {/* ВАЖНО: тут больше НЕ NavLink, чтобы не вкладывать <a> в <a> */}
        <div className="avatar-link" role="button" tabIndex={0}>
          <img src="/avatar.jpg" alt="Profile" className="avatar-sidebar" />
          <div className="avatar-dropdown">
            <div className="avatar-info">
              <div className="avatar-name">Nickname</div>
              <div
                className="avatar-id"
                onClick={(e) => {
                  e.stopPropagation();
                  copyClientId(clientId);
                }}
                style={{ cursor: "pointer" }}
                title="Нажмите чтобы скопировать"
              >
                ID: {clientId} 📋
              </div>
            </div>
            <div className="avatar-actions">
              <NavLink to="/profile" className="avatar-action">
                Профиль
              </NavLink>
              <button className="avatar-action">Выход</button>
            </div>
          </div>
        </div>

        <div className="scrollable-menu hidden-scroll">
          <ul className="menu">
            {mainMenuItems.map((item) => {
              const isMenuOpen = activeMenu === item.menu;
              const isExactActive = isActivePath(item.exact || item.path);
              const isParentActive = item.menu ? isParentMenuActive(item.menu) : false;
              const isItemActive = isMenuOpen || isExactActive || isParentActive;

              const iconSrc = isItemActive
                ? item.iconActive || item.iconInactive
                : item.iconInactive || item.iconActive;

              return (
                <li
                  key={item.name}
                  className={`menu-item ${isItemActive ? "active" : ""}`}
                  onMouseEnter={() => item.menu && MouseEnter(item.menu)}
                  onMouseLeave={MouseLeave}
                >
                  {item.path ? (
                    <NavLink to={item.path} className={isExactActive ? "active" : ""} onClick={() => setActiveMenu(null)}>
                      <MediaIcon src={iconSrc} alt={item.name} className="menu-icon" />
                      <span>{item.name}</span>
                    </NavLink>
                  ) : (
                    <div className={`submenu-toggle ${isParentActive ? "parent-active" : ""}`}>
                      <MediaIcon src={iconSrc} alt={item.name} className="menu-icon" />
                      <span>{item.name}</span>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {activeMenu && renderSubmenu(activeMenu)}
    </>
  );
};

export default Sidebar;
