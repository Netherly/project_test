// src/components/Transactions/TransactionsPage.jsx
import React, { useState, useEffect, useMemo } from "react";
import Sidebar from "../Sidebar";
import AddTransactionModal from "./AddTransactionModal";
import PageHeaderIcon from "../HeaderIcon/PageHeaderIcon.jsx";
import ViewEditTransactionModal from "./ViewEditTransactionModal";
import "../../styles/TransactionsPage.css";

// API бэкенда
import {
  listTransactions,
  createTransactions,
  updateTransaction as apiUpdateTransaction,
  deleteTransaction as apiDeleteTransaction,
  duplicateTransaction as apiDuplicateTransaction,
} from "../../api/transactions";

const TransactionsPage = () => {
  // ====== Локальные дефолтные мок-данные (fallback) ======
  const defaultTransactions = [
    {
      id: "T001",
      date: "2025-07-27 10:30",
      category: "Продажи",
      subcategory: "Онлайн-продажи",
      description: "Оплата за товар #12345",
      accountName: "ПриватБанк - Ключ к счету",
      accountCurrency: "UAH",
      operation: "Зачисление",
      amount: 1500.0,
      counterparty: "Иванов И.И.",
      counterpartyRequisites: "UA987654321098765432109876543",
    },
    {
      id: "T002",
      date: "2025-07-26 15:00",
      category: "Расходы",
      subcategory: "Закупка материалов",
      description: "Оплата поставщику за сырье",
      accountName: "Монобанк - Черная (V) (0574)",
      accountCurrency: "UAH",
      operation: "Списание",
      amount: 500.5,
      counterparty: "ООО 'Поставщик'",
      counterpartyRequisites: "EDRPOU 12345678",
    },
    {
      id: "T003",
      date: "2025-07-25 09:00",
      category: "Зарплата",
      subcategory: "Выдача ЗП",
      description: "Выплата зарплаты сотруднику",
      accountName: "ПриватБанк - Ключ к счету",
      accountCurrency: "UAH",
      operation: "Списание",
      amount: 10000.0,
      counterparty: "Петров П.П.",
      counterpartyRequisites: "Паспорт СН123456",
    },
    {
      id: "T004",
      date: "2025-07-24 11:45",
      category: "Инвестиции",
      subcategory: "Покупка криптовалюты",
      description: "Покупка USDT на бирже",
      accountName: "Binance - Спотовый",
      accountCurrency: "USDT",
      operation: "Зачисление",
      amount: 50.0,
      counterparty: "Binance Exchange",
      counterpartyRequisites: "Binance ID: 987654321",
    },
    {
      id: "T005",
      date: "2025-07-23 18:20",
      category: "Доходы",
      subcategory: "Возврат средств",
      description: "Возврат переплаты от клиента",
      accountName: "Монобанк - Черная (V) (0574)",
      accountCurrency: "UAH",
      operation: "Зачисление",
      amount: 200.0,
      counterparty: "ООО 'Клиент'",
      counterpartyRequisites: "ИНН 87654321",
    },
    {
      id: "T006",
      date: "2025-07-22 09:00",
      category: "Налоги",
      subcategory: "Уплата ЕСВ",
      description: "Уплата единого социального взноса",
      accountName: "ПриватБанк - Ключ к счету",
      accountCurrency: "UAH",
      operation: "Списание",
      amount: 2500.0,
      counterparty: "Государственная Налоговая Служба",
      counterpartyRequisites: "UA456789012345678901234567890",
    },
  ];

  // ====== Состояния ======
  const [transactions, setTransactions] = useState([]);
  const [assets, setAssets] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewEditModalOpen, setIsViewEditModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [financeFields, setFinanceFields] = useState({
    articles: [],
    subarticles: [],
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // ====== Helpers ======
  const sortByDateDesc = (list) =>
    [...list].sort((a, b) => new Date(b.date) - new Date(a.date));

  const getAccountNameById = useMemo(() => {
    const map = new Map(
      (assets || []).map((a) => [String(a.id), a.accountName || a.name || a.id])
    );
    return (accountId, fallbackName) =>
      map.get(String(accountId)) || fallbackName || String(accountId || "");
  }, [assets]);

  // ====== Первичная загрузка: пытаемся с бэка, потом fallback ======
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);

        // assets из localStorage (пока нет явного Assets API на фронте)
        const savedAssets = localStorage.getItem("assetsData");
        if (savedAssets) {
          try {
            setAssets(JSON.parse(savedAssets) || []);
          } catch {
            setAssets([]);
          }
        }

        // financeFields из localStorage (как и раньше)
        const savedFields = localStorage.getItem("fieldsData");
        if (savedFields) {
          try {
            const parsed = JSON.parse(savedFields);
            if (parsed.financeFields) setFinanceFields(parsed.financeFields);
          } catch (_) {}
        }

        // транзакции — пробуем бэк
        let items = [];
        try {
          const { items: serverItems } = await listTransactions({ page: 1, pageSize: 500 });
          items = serverItems || [];
        } catch (e) {
          console.warn("Не удалось получить транзакции с бэка, используем localStorage:", e);
          const savedTransactions = localStorage.getItem("transactionsData");
          if (savedTransactions) {
            try {
              items = JSON.parse(savedTransactions) || [];
            } catch {
              items = defaultTransactions;
            }
          } else {
            items = defaultTransactions;
          }
        }

        // сохраняем в состояние (и для локального кэша — ниже useEffect)
        setTransactions(sortByDateDesc(items));
        setError("");
      } catch (e) {
        console.error(e);
        setError(e?.message || "Ошибка загрузки");
        // fallback на дефолты
        setTransactions(sortByDateDesc(defaultTransactions));
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ====== Кэш в localStorage + пересчёт балансов активов ======
  useEffect(() => {
    // кэшируем список транзакций
    localStorage.setItem("transactionsData", JSON.stringify(transactions));
    // поддерживаем расчётные поля активов в LS
    updateAssetsInLocalStorage(transactions);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transactions]);

  // Пересчёт активов на основе транзакций (как у тебя было)
  const updateAssetsInLocalStorage = (updatedTransactions) => {
    const savedAssets = JSON.parse(localStorage.getItem("assetsData")) || [];
    const updatedAssets = savedAssets.map((asset) => {
      const assetTransactions = updatedTransactions.filter(
        (t) =>
          // поддержка обоих вариантов: accountId (uuid) ИЛИ старое account (имя)
          t.accountId === asset.id || t.account === asset.id
      );
      const totalIncoming = assetTransactions
        .filter((t) => t.operation === "Зачисление")
        .reduce((sum, t) => sum + Number(t.amount || 0), 0);
      const totalOutgoing = assetTransactions
        .filter((t) => t.operation === "Списание")
        .reduce((sum, t) => sum + Number(t.amount || 0), 0);

      const newBalance = (
        Number(asset.turnoverStartBalance || 0) +
        totalIncoming -
        totalOutgoing
      ).toFixed(2);

      return {
        ...asset,
        balance: parseFloat(newBalance),
        turnoverIncoming: totalIncoming,
        turnoverOutgoing: totalOutgoing,
        turnoverEndBalance: parseFloat(newBalance),
      };
    });
    localStorage.setItem("assetsData", JSON.stringify(updatedAssets));
  };

  // ====== Clipboard ======
  const copyToClipboard = (text) => {
    if (!text) return;
    navigator.clipboard
      .writeText(text)
      .then(() => alert("Скопировано!"))
      .catch((err) => console.error("Не удалось скопировать: ", err));
  };

  // ====== CRUD ======
  const handleAddTransaction = async (newTransaction) => {
    try {
      setSaving(true);
      // Нормализуем форму к бэкенду:
      // - если модалка отдаёт поле account (имя), то не трогаем
      // - если отдаёт accountId — тоже ок
      const payload = {
        ...newTransaction,
        // на бэке ожидается date как "YYYY-MM-DD HH:mm" или ISO — форма уже даёт строку
      };

      const created = await createTransactions(payload);
      const createdList = Array.isArray(created) ? created : [created];

      // мержим в список и сортируем
      setTransactions((prev) => sortByDateDesc([...prev, ...createdList]));
    } catch (e) {
      console.error("Ошибка создания транзакции:", e);
      alert(e?.message || "Не удалось создать транзакцию");
    } finally {
      setSaving(false);
      setIsAddModalOpen(false);
    }
  };

  const handleUpdateTransaction = async (updatedTransaction) => {
    try {
      setSaving(true);
      const id = updatedTransaction.id;
      const saved = await apiUpdateTransaction(id, updatedTransaction);

      setTransactions((prev) =>
        sortByDateDesc(prev.map((t) => (t.id === id ? saved : t)))
      );
      setIsViewEditModalOpen(false);
      setSelectedTransaction(null);
    } catch (e) {
      console.error("Ошибка обновления транзакции:", e);
      alert(e?.message || "Не удалось обновить транзакцию");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTransaction = async (transactionId) => {
    try {
      setSaving(true);
      await apiDeleteTransaction(transactionId);
      setTransactions((prev) => prev.filter((t) => t.id !== transactionId));
    } catch (e) {
      console.error("Ошибка удаления транзакции:", e);
      alert(e?.message || "Не удалось удалить транзакцию");
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicateTransaction = async (transactionToDuplicate) => {
    try {
      setSaving(true);
      const dup = await apiDuplicateTransaction(transactionToDuplicate.id);
      setTransactions((prev) => sortByDateDesc([dup, ...prev]));
    } catch (e) {
      console.error("Ошибка дублирования транзакции:", e);
      alert(e?.message || "Не удалось дублировать транзакцию");
    } finally {
      setSaving(false);
    }
  };

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction);
    setIsViewEditModalOpen(true);
  };

  // ====== Отрисовка ======
  return (
    <div className="transactions-page">
      <Sidebar />

      <div className="transactions-page-main-container">
        <header className="transactions-header-container">
          <h1 className="transactions-title">
            <PageHeaderIcon pageName="Транзакции" />
            Транзакции
          </h1>

          <div className="add-transaction-wrapper">
            {loading && <span className="loading-label">Загрузка…</span>}
            {saving && <span className="loading-label">Сохранение…</span>}
            <button
              className="add-transaction-button"
              onClick={() => setIsAddModalOpen(true)}
              disabled={saving}
            >
              ➕ Добавить транзакцию
            </button>
          </div>
        </header>

        {error && (
          <div className="error-banner">
            {error}
          </div>
        )}

        <div className="transactions-table-container">
          <table className="transactions-table">
            <thead>
              <tr>
                <th>Дата и время</th>
                <th>Статья</th>
                <th>Подстатья</th>
                <th>Описание</th>
                <th>Счет</th>
                <th>Валюта счета</th>
                <th>Операция</th>
                <th>Сумма операции</th>
                <th>Контрагент</th>
                <th>Реквизиты контрагента</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((transaction) => {
                const accTitle =
                  transaction.accountName ||
                  getAccountNameById(transaction.accountId, transaction.account);

                const amountNum =
                  typeof transaction.amount === "number"
                    ? transaction.amount
                    : Number(transaction.amount || 0);

                return (
                  <tr
                    key={transaction.id}
                    className="transaction-row"
                    onClick={() => handleTransactionClick(transaction)}
                  >
                    <td>{transaction.date}</td>
                    <td>{transaction.category}</td>
                    <td>{transaction.subcategory}</td>
                    <td>{transaction.description}</td>
                    <td>
                      <div className="account-info">
                        <span className="account-main-name">{accTitle}</span>
                      </div>
                    </td>
                    <td>{transaction.accountCurrency}</td>
                    <td>{transaction.operation}</td>
                    <td
                      className={
                        transaction.operation === "Зачисление"
                          ? "amount-positive"
                          : "amount-negative"
                      }
                    >
                      {amountNum.toFixed(2)}
                    </td>
                    <td>{transaction.counterparty}</td>
                    <td>
                      <div className="copy-button-container">
                        {transaction.counterpartyRequisites}
                        <span
                          className="copy-button-icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(transaction.counterpartyRequisites);
                          }}
                          title="Копировать реквизиты"
                        ></span>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {!loading && transactions.length === 0 && (
                <tr>
                  <td colSpan={10} style={{ textAlign: "center", opacity: 0.7 }}>
                    Транзакций пока нет
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isAddModalOpen && (
        <AddTransactionModal
          onAdd={handleAddTransaction}
          onClose={() => setIsAddModalOpen(false)}
          assets={assets}
          financeFields={financeFields}
        />
      )}

      {isViewEditModalOpen && selectedTransaction && (
        <ViewEditTransactionModal
          transaction={selectedTransaction}
          onUpdate={handleUpdateTransaction}
          onDelete={handleDeleteTransaction}
          onDuplicate={handleDuplicateTransaction}
          onClose={() => {
            setIsViewEditModalOpen(false);
            setSelectedTransaction(null);
          }}
          assets={assets}
          financeFields={financeFields}
        />
      )}
    </div>
  );
};

export default TransactionsPage;
