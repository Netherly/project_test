// src/components/Transactions/AddTransactionModal.jsx
import React, { useState, useEffect, useMemo } from "react";
import "../../styles/AddTransactionModal.css";
import { createTransactions } from "../../api/transactions";
import { AssetsAPI } from "../../api/assets";
import { getLatestRates } from "../../api/rates";

const generateId = (prefix) =>
  prefix +
  Math.random().toString(36).substring(2, 9) +
  Date.now().toString(36).substring(4, 9);

const toStr = (v, fb = "") =>
  v == null ? fb : typeof v === "object"
    ? String(v.code ?? v.value ?? v.symbol ?? v.name ?? fb)
    : String(v);

const pickCurrencyCode = (a) =>
  toStr(a?.currency) || toStr(a?.baseCurrency) || toStr(a?.curr) || "UAH";

const pickAccountName = (a, idFb = "") =>
  toStr(a?.accountName) ||
  toStr(a?.name) ||
  toStr(a?.title) ||
  toStr(a?.alias) ||
  (idFb ? `Счёт • ${String(idFb).slice(-6)}` : "Без названия");

function normalizeAssetForForm(a = {}) {
  const id = a.id ?? a._id ?? a.uuid ?? "";
  const accountName = pickAccountName(a, id);
  const currency = pickCurrencyCode(a);
  return { id, accountName, currency, __raw: a };
}
const normalizeManyAssets = (list) =>
  Array.isArray(list) ? list.map(normalizeAssetForForm) : [];

function normalizeRatesPayload(payload) {
  if (payload && typeof payload.pairs === "object") return payload.pairs;
  if (payload && Array.isArray(payload.items)) {
    return payload.items.reduce((acc, it) => {
      if (it && it.from && it.to && (it.rate ?? it.value)) {
        acc[`${it.from}_${it.to}`] = Number(it.rate ?? it.value);
      }
      return acc;
    }, {});
  }
  if (payload && typeof payload === "object") return payload;
  return {};
}

const AddTransactionModal = ({
  onAdd,
  onClose,
  assets: assetsProp = [],
  financeFields,
}) => {
  const getCurrentDateTime = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, "0");
    const day = now.getDate().toString().padStart(2, "0");
    const hours = now.getHours().toString().padStart(2, "0");
    const minutes = now.getMinutes().toString().padStart(2, "0");
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const [assets, setAssets] = useState(normalizeManyAssets(assetsProp));
  const [assetsLoading, setAssetsLoading] = useState(false);
  const [assetsError, setAssetsError] = useState("");

  useEffect(() => {
    let isMounted = true;
    async function loadAssets() {
      setAssetsLoading(true);
      setAssetsError("");
      try {
        const data = await AssetsAPI.list({ page: 1, pageSize: 500 });
        if (isMounted && Array.isArray(data)) {
          setAssets(normalizeManyAssets(data));
        }
      } catch (e) {
        if (isMounted) setAssetsError("Не удалось загрузить активы.");
      } finally {
        if (isMounted) setAssetsLoading(false);
      }
    }
    if (!assetsProp || assetsProp.length === 0) {
      loadAssets();
    } else {
      setAssets(normalizeManyAssets(assetsProp));
      loadAssets();
    }
    return () => {
      isMounted = false;
    };
  }, [assetsProp]);

  const [formData, setFormData] = useState({
    date: getCurrentDateTime(),
    category: financeFields?.articles?.[0]?.articleValue || "",
    subcategory: "",
    description: "",
    accountId: "",
    accountName: "",
    accountCurrency: "UAH",
    operation: "Зачисление",
    amount: "",
    commission: "",
    counterparty: "",
    counterpartyRequisites: "",
    orderId: "",
    orderNumber: "",
    orderCurrency: "",
    sumUAH: "",
    sumUSD: "",
    sumRUB: "",
    sumByRatesOrderAmountCurrency: "",
    sumByRatesUAH: "",
    sumByRatesUSD: "",
    sumByRatesRUB: "",
    sentToCounterparty: false,
    sendLion: false,
    id: generateId("TRX_"),
  });

  const [currentRates, setCurrentRates] = useState(null);
  const [ratesError, setRatesError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setRatesError("");
        const latest = await getLatestRates();
        const pairs = normalizeRatesPayload(latest);
        if (!cancelled && pairs && Object.keys(pairs).length) {
          setCurrentRates(pairs);
          localStorage.setItem("currencyRates", JSON.stringify([pairs]));
          return;
        }
      } catch {
        setRatesError("Не удалось загрузить текущие курсы.");
      }
      try {
        const saved = localStorage.getItem("currencyRates");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (!cancelled && parsed && parsed.length > 0) {
            setCurrentRates(parsed[0]);
          }
        }
      } catch {}
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const [showCommissionField, setShowCommissionField] = useState(false);
  const [showOrderBlock, setShowOrderBlock] = useState(false);

  const [destinationAccounts, setDestinationAccounts] = useState([
    { id: generateId("DEST_"), accountId: "", accountCurrency: "UAH", amount: "", commission: "" },
  ]);
  const [showDestinationAccountsBlock, setShowDestinationAccountsBlock] =
    useState(false);

  const availableSubcategories = useMemo(() => {
    if (!formData.category || !financeFields?.subarticles) return [];
    return financeFields.subarticles.filter(
      (sub) => sub.subarticleInterval === formData.category
    );
  }, [formData.category, financeFields]);

  const counterparties = [
    "Иванов И.И.",
    "ООО 'Поставщик'",
    "Петров П.П.",
    "Binance Exchange",
    "ООО 'Клиент'",
    "Государственная Налоговая Служба",
  ];
  const counterpartyRequisitesMap = {
    "Иванов И.И.": {
      UAH: "UA987654321098765432109876543",
      USD: "US987654321098765432109876543",
    },
    "ООО 'Поставщик'": { UAH: "EDRPOU 12345678" },
    "Петров П.П.": { UAH: "Паспорт СН123456" },
    "Binance Exchange": { USDT: "Binance ID: 987654321" },
    "ООО 'Клиент'": { UAH: "ИНН 87654321" },
    "Государственная Налоговая Служба": {
      UAH: "UA456789012345678901234567890",
    },
  };

  const activeOrders = [
    { id: "ORD001", number: "P-54321", currency: "UAH", amount: 1200 },
    { id: "ORD002", number: "S-98765", currency: "USD", amount: 50 },
    { id: "ORD003", number: "K-11223", currency: "RUB", amount: 3000 },
  ];

  const convertCurrency = (amount, fromCurrency, toCurrency) => {
    if (!currentRates || !amount || isNaN(amount) || Number(amount) === 0) return "";
    if (fromCurrency === toCurrency) return Number(amount).toFixed(2);
    const rateKey = `${fromCurrency}_${toCurrency}`;
    const reverseRateKey = `${toCurrency}_${fromCurrency}`;
    let rate = currentRates[rateKey];
    if (rate === undefined && currentRates[reverseRateKey] !== undefined) {
      rate = 1 / currentRates[reverseRateKey];
    }
    if (rate === undefined) return "";
    return (Number(amount) * rate).toFixed(2);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    let newValue = type === "checkbox" ? checked : value;
    let next = { ...formData, [name]: newValue };

    if (name === "category") {
      next.subcategory = "";
      if (value === "Смена счета") {
        setShowDestinationAccountsBlock(true);
        next.operation = "Списание";
        setDestinationAccounts([
          { id: generateId("DEST_"), accountId: "", accountCurrency: "UAH", amount: "", commission: "" },
        ]);
      } else {
        setShowDestinationAccountsBlock(false);
      }
    }

    if (name === "accountId") {
      const selected = assets.find((a) => a.id === newValue);
      next.accountCurrency = selected ? selected.currency : "UAH";
      next.accountName = selected ? selected.accountName : "";
      const currentAmount = parseFloat(next.amount);
      if (currentAmount && currentRates && next.accountCurrency) {
        next.sumUAH = convertCurrency(currentAmount, next.accountCurrency, "UAH");
        next.sumUSD = convertCurrency(currentAmount, next.accountCurrency, "USD");
        next.sumRUB = convertCurrency(currentAmount, next.accountCurrency, "RUB");
      } else {
        next.sumUAH = "";
        next.sumUSD = "";
        next.sumRUB = "";
      }
    }

    if (name === "counterparty") {
      const selectedReq = counterpartyRequisitesMap[newValue];
      next.counterpartyRequisites = selectedReq
        ? selectedReq[next.accountCurrency] || Object.values(selectedReq)[0] || ""
        : "";
    }

    if (name === "amount" || name === "category" || name === "accountId") {
      const currentAmount =
        name === "amount" ? parseFloat(newValue) : parseFloat(next.amount);
      const currentCategory = name === "category" ? newValue : next.category;
      setShowCommissionField(currentCategory === "Смена счета" && currentAmount > 0);
      const cur =
        name === "accountId"
          ? assets.find((a) => a.id === newValue)?.currency || "UAH"
          : next.accountCurrency;
      if (currentAmount && currentRates && cur) {
        next.sumUAH = convertCurrency(currentAmount, cur, "UAH");
        next.sumUSD = convertCurrency(currentAmount, cur, "USD");
        next.sumRUB = convertCurrency(currentAmount, cur, "RUB");
      } else {
        next.sumUAH = "";
        next.sumUSD = "";
        next.sumRUB = "";
      }
    }

    if (name === "orderNumber") {
      if (newValue) {
        const sel = activeOrders.find((o) => o.number === newValue);
        if (sel) {
          next = {
            ...next,
            orderId: sel.id,
            orderCurrency: sel.currency,
            sumByRatesOrderAmountCurrency: sel.amount.toFixed(2),
            sumByRatesUAH: convertCurrency(sel.amount, sel.currency, "UAH"),
            sumByRatesUSD: convertCurrency(sel.amount, sel.currency, "USD"),
            sumByRatesRUB: convertCurrency(sel.amount, sel.currency, "RUB"),
          };
        }
        setShowOrderBlock(true);
      } else {
        setShowOrderBlock(false);
        next = {
          ...next,
          orderId: "",
          orderCurrency: "",
          sumByRatesOrderAmountCurrency: "",
          sumByRatesUAH: "",
          sumByRatesUSD: "",
          sumByRatesRUB: "",
        };
      }
    }

    setFormData(next);
  };

  const handleDestinationAccountChange = (e, id) => {
    const { name, value } = e.target;
    setDestinationAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id !== id) return acc;
        const next = { ...acc, [name]: value };
        if (name === "accountId") {
          const sel = assets.find((a) => a.id === value);
          next.accountCurrency = sel ? sel.currency : "UAH";
        }
        return next;
      })
    );
  };

  const addDestinationAccount = () => {
    if (destinationAccounts.length < 3) {
      setDestinationAccounts((prev) => [
        ...prev,
        { id: generateId("DEST_"), accountId: "", accountCurrency: "UAH", amount: "", commission: "" },
      ]);
    }
  };

  const removeDestinationAccount = (id) => {
    setDestinationAccounts((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (formData.category === "Смена счета") {
        const transactions = [];
        const totalAmountToTransfer = destinationAccounts.reduce(
          (sum, acc) => sum + parseFloat(acc.amount || 0),
          0
        );
        const totalCommission = destinationAccounts.reduce(
          (sum, acc) => sum + parseFloat(acc.commission || 0),
          0
        );
        const totalWithdrawal = totalAmountToTransfer + totalCommission;
        const srcAsset = assets.find((a) => a.id === formData.accountId);
        const t1 = {
          date: formData.date.replace("T", " "),
          category: formData.category,
          subcategory: formData.subcategory || null,
          description: `Перевод на счета: ${destinationAccounts
            .map((d) => assets.find((a) => a.id === d.accountId)?.accountName)
            .filter(Boolean)
            .join(", ")}`,
          accountId: formData.accountId,
          accountName: srcAsset?.accountName || formData.accountName || null,
          accountCurrency: srcAsset?.currency || formData.accountCurrency || "UAH",
          operation: "Списание",
          amount: Number(totalWithdrawal),
          commission: Number(totalCommission) || 0,
          counterparty: formData.counterparty || null,
          counterpartyRequisites: formData.counterpartyRequisites || null,
          orderId: formData.orderId || null,
          orderNumber: formData.orderNumber || null,
          orderCurrency: formData.orderCurrency || null,
          sumUAH: formData.sumUAH ? Number(formData.sumUAH) : null,
          sumUSD: formData.sumUSD ? Number(formData.sumUSD) : null,
          sumRUB: formData.sumRUB ? Number(formData.sumRUB) : null,
          sumByRatesOrderAmountCurrency: formData.sumByRatesOrderAmountCurrency
            ? Number(formData.sumByRatesOrderAmountCurrency)
            : null,
          sumByRatesUAH: formData.sumByRatesUAH ? Number(formData.sumByRatesUAH) : null,
          sumByRatesUSD: formData.sumByRatesUSD ? Number(formData.sumByRatesUSD) : null,
          sumByRatesRUB: formData.sumByRatesRUB ? Number(formData.sumByRatesRUB) : null,
          sentToCounterparty: Boolean(formData.sentToCounterparty),
          sendLion: Boolean(formData.sendLion),
        };
        transactions.push(t1);
        destinationAccounts.forEach((dest) => {
          const destAsset = assets.find((a) => a.id === dest.accountId);
          const t2 = {
            date: formData.date.replace("T", " "),
            category: formData.category,
            subcategory: formData.subcategory || null,
            description: `Перевод со счета ${srcAsset?.accountName || "источник"}`,
            accountId: dest.accountId,
            accountName: destAsset?.accountName || null,
            accountCurrency: destAsset?.currency || "UAH",
            operation: "Зачисление",
            amount: Number(dest.amount || 0),
            commission: Number(dest.commission || 0),
            counterparty: null,
            counterpartyRequisites: null,
            orderId: null,
            orderNumber: null,
            orderCurrency: null,
            sumUAH: null,
            sumUSD: null,
            sumRUB: null,
            sumByRatesOrderAmountCurrency: null,
            sumByRatesUAH: null,
            sumByRatesUSD: null,
            sumByRatesRUB: null,
            sentToCounterparty: false,
            sendLion: false,
          };
          transactions.push(t2);
        });
        const created = await createTransactions(transactions);
        onAdd(Array.isArray(created) ? created : transactions);
      } else {
        const asset = assets.find((a) => a.id === formData.accountId);
        const payload = {
          date: formData.date.replace("T", " "),
          category: formData.category,
          subcategory: formData.subcategory || null,
          description: formData.description || null,
          accountId: formData.accountId,
          accountName: asset?.accountName || formData.accountName || null,
          accountCurrency: asset?.currency || formData.accountCurrency || "UAH",
          operation: formData.operation,
          amount: Number(formData.amount),
          commission:
            showCommissionField && formData.commission !== ""
              ? Number(formData.commission)
              : null,
          counterparty: formData.counterparty || null,
          counterpartyRequisites: formData.counterpartyRequisites || null,
          orderId: formData.orderId || null,
          orderNumber: formData.orderNumber || null,
          orderCurrency: formData.orderCurrency || null,
          sumUAH: formData.sumUAH ? Number(formData.sumUAH) : null,
          sumUSD: formData.sumUSD ? Number(formData.sumUSD) : null,
          sumRUB: formData.sumRUB ? Number(formData.sumRUB) : null,
          sumByRatesOrderAmountCurrency: formData.sumByRatesOrderAmountCurrency
            ? Number(formData.sumByRatesOrderAmountCurrency)
            : null,
          sumByRatesUAH: formData.sumByRatesUAH ? Number(formData.sumByRatesUAH) : null,
          sumByRatesUSD: formData.sumByRatesUSD ? Number(formData.sumByRatesUSD) : null,
          sumByRatesRUB: formData.sumByRatesRUB ? Number(formData.sumByRatesRUB) : null,
          sentToCounterparty: Boolean(formData.sentToCounterparty),
          sendLion: Boolean(formData.sendLion),
        };
        const created = await createTransactions(payload);
        onAdd(created);
      }
      onClose();
    } catch (error) {
      console.error("Ошибка при сохранении транзакции:", error);
      alert("Ошибка при сохранении транзакции. Проверьте консоль.");
    }
  };

  const hasAssets = assets && assets.length > 0;

  return (
    <div className="add-transaction-overlay">
      <div className="add-transaction-modal">
        <div className="add-transaction-header">
          <h2>Добавить транзакцию</h2>
          <div className="add-transaction-actions">
            <span className="icon" onClick={onClose}>✖️</span>
          </div>
        </div>

        {assetsLoading && <div className="info-banner">Загружаем счета...</div>}
        {assetsError && <div className="error-banner">{assetsError}</div>}
        {ratesError && <div className="error-banner">{ratesError}</div>}

        <form onSubmit={handleSubmit} className="add-transaction-form">
          <div className="form-row">
            <label htmlFor="date" className="form-label">Дата и время операции</label>
            <input
              type="datetime-local"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
              className="form-input"
            />
          </div>

          <div className="form-row">
            <label htmlFor="category" className="form-label">Статья</label>
            <select
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
              className="form-input"
            >
              <option value="" disabled>Выберите статью</option>
              {financeFields?.articles?.map((a, i) => (
                <option key={i} value={a.articleValue}>{a.articleValue}</option>
              ))}
              {!financeFields?.articles?.some((a) => a.articleValue === "Смена счета") && (
                <option value="Смена счета">Смена счета</option>
              )}
            </select>
          </div>

          {availableSubcategories.length > 0 && (
            <div className="form-row">
              <label htmlFor="subcategory" className="form-label">Подстатья</label>
              <select
                id="subcategory"
                name="subcategory"
                value={formData.subcategory}
                onChange={handleChange}
                required
                className="form-input"
              >
                <option value="">Выберите подстатью</option>
                {availableSubcategories.map((sub, i) => (
                  <option key={i} value={sub.subarticleValue}>{sub.subarticleValue}</option>
                ))}
              </select>
            </div>
          )}

          <div className="form-row">
            <label htmlFor="description" className="form-label">Описание</label>
            <input
              type="text"
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Введите описание"
              className="form-input"
            />
          </div>

          <div className="form-row">
            <label htmlFor="accountId" className="form-label">
              Счет {formData.accountCurrency ? `(${formData.accountCurrency})` : ""}
            </label>
            <select
              id="accountId"
              name="accountId"
              value={formData.accountId}
              onChange={handleChange}
              required
              className="form-input"
              disabled={!hasAssets}
            >
              <option value="">{hasAssets ? "Выберите счет" : "Нет доступных счетов"}</option>
              {hasAssets &&
                assets.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.accountName} {acc.currency ? `• ${acc.currency}` : ""}
                  </option>
                ))}
            </select>
          </div>

          <div className="form-row">
            <label htmlFor="operation" className="form-label">Операция</label>
            <select
              id="operation"
              name="operation"
              value={formData.operation}
              onChange={handleChange}
              required
              className="form-input"
              disabled={showDestinationAccountsBlock}
            >
              <option value="Зачисление">Зачисление</option>
              <option value="Списание">Списание</option>
            </select>
          </div>

          {!showDestinationAccountsBlock && (
            <>
              <div className="form-row">
                <label htmlFor="amount" className="form-label">Сумма операции</label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleChange}
                  placeholder="Введите сумму"
                  required
                  step="0.01"
                  className="form-input"
                />
              </div>

              <div className="form-row">
                <label htmlFor="commission" className="form-label">Комиссия</label>
                <input
                  type="number"
                  id="commission"
                  name="commission"
                  value={formData.commission}
                  onChange={handleChange}
                  placeholder="Введите комиссию"
                  step="0.01"
                  className="form-input"
                />
              </div>
            </>
          )}

          {formData.amount && !showDestinationAccountsBlock && (
            <div className="currency-recalculation-block">
              <div className="form-row">
                <label className="form-label">Сумма операции (₴)</label>
                <span className="form-value readonly">{formData.sumUAH}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма операции ($)</label>
                <span className="form-value readonly">{formData.sumUSD}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма операции (руб)</label>
                <span className="form-value readonly">{formData.sumRUB}</span>
              </div>
              <div className="form-row">
                <label className="form-label small-label">Пересчет согласно текущим курсам</label>
                <span className="form-value" />
              </div>
            </div>
          )}

          {showDestinationAccountsBlock &&
            destinationAccounts.map((dest, index) => (
              <div className="duplicated-account-block" key={dest.id}>
                <div className="form-row flex-row">
                  <label htmlFor={`dest-account-${dest.id}`} className="form-label">
                    Счет зачисления {dest.accountCurrency ? `(${dest.accountCurrency})` : ""}
                  </label>
                  <div className="input-with-actions">
                    <select
                      id={`dest-account-${dest.id}`}
                      name="accountId"
                      value={dest.accountId}
                      onChange={(e) => handleDestinationAccountChange(e, dest.id)}
                      required
                      className="form-input"
                      disabled={!hasAssets}
                    >
                      <option value="">
                        {hasAssets ? "Выберите счет зачисления" : "Нет доступных счетов"}
                      </option>
                      {hasAssets &&
                        assets.map((acc) => (
                          <option key={`dest-${dest.id}-${acc.id}`} value={acc.id}>
                            {acc.accountName} {acc.currency ? `• ${acc.currency}` : ""}
                          </option>
                        ))}
                    </select>
                    {index === 0 && destinationAccounts.length < 3 && (
                      <button
                        type="button"
                        onClick={addDestinationAccount}
                        className="action-button add-button"
                        title="Добавить счёт назначения"
                      >
                        +
                      </button>
                    )}
                    {index > 0 && (
                      <button
                        type="button"
                        onClick={() => removeDestinationAccount(dest.id)}
                        className="action-button remove-button"
                        title="Удалить этот счёт назначения"
                      >
                        ✖️
                      </button>
                    )}
                  </div>
                </div>

                <div className="form-row">
                  <label htmlFor={`dest-amount-${dest.id}`} className="form-label">Сумма</label>
                  <input
                    type="number"
                    id={`dest-amount-${dest.id}`}
                    name="amount"
                    value={dest.amount}
                    onChange={(e) => handleDestinationAccountChange(e, dest.id)}
                    placeholder="Введите сумму"
                    required
                    step="0.01"
                    className="form-input"
                  />
                </div>

                <div className="form-row">
                  <label htmlFor={`dest-commission-${dest.id}`} className="form-label">Комиссия</label>
                  <input
                    type="number"
                    id={`dest-commission-${dest.id}`}
                    name="commission"
                    value={dest.commission}
                    onChange={(e) => handleDestinationAccountChange(e, dest.id)}
                    placeholder="Введите комиссию"
                    step="0.01"
                    className="form-input"
                  />
                </div>

                <div className="form-row-divider" />
              </div>
            ))}

          <div className="form-row">
            <label htmlFor="counterparty" className="form-label">Контрагент</label>
            <select
              id="counterparty"
              name="counterparty"
              value={formData.counterparty}
              onChange={handleChange}
              className="form-input"
            >
              <option value="">Выберите контрагента</option>
              {counterparties.map((cp) => (
                <option key={cp} value={cp}>{cp}</option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <label htmlFor="counterpartyRequisites" className="form-label">Реквизиты контрагента</label>
            <input
              type="text"
              id="counterpartyRequisites"
              name="counterpartyRequisites"
              value={formData.counterpartyRequisites}
              readOnly
              className="form-input readonly"
            />
          </div>

          <div className="form-row">
            <label htmlFor="orderNumber" className="form-label">№ заказа</label>
            <select
              id="orderNumber"
              name="orderNumber"
              value={formData.orderNumber}
              onChange={handleChange}
              className="form-input"
            >
              <option value="">Выберите номер заказа</option>
              {activeOrders.map((order) => (
                <option key={order.id} value={order.number}>{order.number}</option>
              ))}
            </select>
          </div>

          {showOrderBlock && (
            <div className="order-details-block">
              <div className="form-row">
                <label className="form-label">ID заказа</label>
                <span className="form-value readonly">{formData.orderId}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Валюта заказа</label>
                <span className="form-value readonly">{formData.orderCurrency}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма по курсам заказа в валюте заказа</label>
                <span className="form-value readonly">{formData.sumByRatesOrderAmountCurrency}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма по курсам заказа в гривне</label>
                <span className="form-value readonly">{formData.sumByRatesUAH}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма по курсам заказа в долларах</label>
                <span className="form-value readonly">{formData.sumByRatesUSD}</span>
              </div>
              <div className="form-row">
                <label className="form-label">Сумма по курсам заказа в рублях</label>
                <span className="form-value readonly">{formData.sumByRatesRUB}</span>
              </div>
            </div>
          )}

          <div className="form-row checkbox-row">
            <label htmlFor="sentToCounterparty" className="form-label">Отправлено контрагенту</label>
            <input
              type="checkbox"
              id="sentToCounterparty"
              name="sentToCounterparty"
              checked={formData.sentToCounterparty}
              onChange={handleChange}
              className="form-checkbox"
            />
          </div>

          <div className="form-row second-checkbox-row">
            <label htmlFor="sendLion" className="form-label">Отправить 🦁</label>
            <input
              type="checkbox"
              id="sendLion"
              name="sendLion"
              checked={formData.sendLion}
              onChange={handleChange}
              className="form-checkbox"
            />
          </div>

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>Отменить</button>
            <button
              type="submit"
              className="save-button"
              disabled={!hasAssets}
              title={!hasAssets ? "Нет доступных счетов" : "Сохранить"}
            >
              Сохранить
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddTransactionModal;
